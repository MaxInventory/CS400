import java.util.PriorityQueue;
import java.util.List;
import java.util.LinkedList;
import java.util.NoSuchElementException;
import java.util.Arrays;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * This class extends the BaseGraph data structure with additional methods for
 * computing the total cost and list of node data along the shortest path
 * connecting a provided starting to ending nodes. This class makes use of
 * Dijkstra's shortest path algorithm.
 */
public class DijkstraGraph<NodeType, EdgeType extends Number>
        extends BaseGraph<NodeType, EdgeType>
        implements GraphADT<NodeType, EdgeType> {

    /**
     * While searching for the shortest path between two nodes, a SearchNode
     * contains data about one specific path between the start node and another
     * node in the graph. The final node in this path is stored in its node
     * field. The total cost of this path is stored in its cost field. And the
     * predecessor SearchNode within this path is referenced by the predecessor
     * field (this field is null within the SearchNode containing the starting
     * node in its node field).
     *
     * SearchNodes are Comparable and are sorted by cost so that the lowest cost
     * SearchNode has the highest priority within a java.util.PriorityQueue.
     */
    protected class SearchNode implements Comparable<SearchNode> {
        public Node node;
        public double cost;
        public SearchNode pred;

        public SearchNode(Node startNode) {
            this.node = startNode;
            this.cost = 0;
            this.pred = null;
        }

        public SearchNode(SearchNode pred, Edge newEdge) {
            this.node = newEdge.succ;
            this.cost = pred.cost + newEdge.data.doubleValue();
            this.pred = pred;
        }

        public int compareTo(SearchNode other) {
            if (cost > other.cost)
                return +1;
            if (cost < other.cost)
                return -1;
            return 0;
        }
    }

    /**
     * Constructor that sets the map that the graph uses.
     */
    public DijkstraGraph() {
        super(new PlaceholderMap<>());
    }

    /**
     * Insert a new directed edge with a non-negative weight into the graph. If 
     * an edge between pred and succ already exists, update the data stored in 
     * that edge to the new weight.
     * 
     * @param pred is the data contained in the new edge's predecesor node
     * @param succ is the data contained in the new edge's succ node
     * @param weight is the non-negative data to be stored in the new edge
     * @return true if the edge could be inserted or updated, or false if the 
     * pred or succ data are not found in any graph nodes or the weight 
     * specified is negative.
     */
    @Override
    public boolean insertEdge(NodeType pred, NodeType succ, EdgeType weight) {
        if (weight.doubleValue() < 0)
            return false;
        return super.insertEdge(pred, succ, weight);
    }

    /**
     * This helper method creates a network of SearchNodes while computing the
     * shortest path between the provided start and end locations. The
     * SearchNode that is returned by this method represents the end of the
     * shortest path that is found: it's cost is the cost of that shortest path,
     * and the nodes linked together through predecessor references represent
     * all of the nodes along that shortest path (ordered from end to start).
     *
     * @param start the starting node for the path
     * @param end   the destination node for the path
     * @return SearchNode for the final end node within the shortest path
     * @throws NoSuchElementException if either the start or the end node
     * cannot be found, or there is no path from start node to end node
     * @throws NullPointerException if the start or end node are null
     */
    protected SearchNode computeShortestPath(Node start, Node end) {
	if (start == null || end == null) {
		throw new NullPointerException("Node start or end is null");
	}

	PriorityQueue<SearchNode> priorityQueue = new PriorityQueue<>();
        PlaceholderMap<Node, Node> visited = new PlaceholderMap<>();

	priorityQueue.add(new SearchNode(start));

	while (!priorityQueue.isEmpty()) {
		SearchNode now = priorityQueue.poll();

		//skip if it have been visited
		if (visited.containsKey(now.node)) {
			continue;
		}

		//mark visited
		visited.put(now.node, now.node);

		//if reach end, return the shortest path
		if (now.node == end) {
			return now;
		}

		for (Edge edge : now.node.edgesLeaving) {
			if (!visited.containsKey(edge.succ)) {
				SearchNode next = new SearchNode(now, edge);
				priorityQueue.add(next);
			}
		}

	}
	throw new NoSuchElementException("Path do not exist (start -X-> end)");
    }
     /**
     * Returns the list of data values from nodes along the shortest path
     * from the node with the provided start value through the node with the
     * provided end value. This list of data values starts with the start
     * value, ends with the end value, and contains intermediary values in the
     * order they are encountered while traversing this shortest path. This
     * method uses Dijkstra's shortest path algorithm to find this solution.
     *
     * @param start the data item in the starting node for the path
     * @param end   the data item in the destination node for the path
     * @return list of data item from nodes along this shortest path
     * @throws NoSuchElementException if either the start or the end node
     * cannot be found, or there is no path from start node to end node
     * @throws NullPointerException if the start or end node are null
     */
    public List<NodeType> shortestPathData(NodeType start, NodeType end) {
	if (start == null || end == null) {
		throw new NullPointerException("Node start or end is null");
	}

	//check if the start and end really exist in the nodes.
	Node checkStart = this.nodes.get(start);
	Node checkEnd = this.nodes.get(end);

	SearchNode shortPath = computeShortestPath(checkStart, checkEnd);
	LinkedList<NodeType> pathData = new LinkedList<>();

	while(shortPath != null) {
		pathData.addFirst(shortPath.node.data);
		shortPath = shortPath.pred;
	}

        return pathData;
    }

    /**
     * Returns the cost of the path (sum over edge weights) of the shortest
     * path from the node containing the start data to the node containing the
     * end data. This method uses Dijkstra's shortest path algorithm to find
     * this solution.
     *
     * @param start the data item in the starting node for the path
     * @param end   the data item in the destination node for the path
     * @return the cost of the shortest path between these nodes
     * @throws NoSuchElementException if either the start or the end node
     * cannot be found, or there is no path from start node to end node
     * @throws NullPointerException if the start or end node are null
     */
    public double shortestPathCost(NodeType start, NodeType end) {
	if (start == null || end == null) {
		throw new NullPointerException("Node start or end is null");
	}

	//check if the start and end really exist in the nodes.
	Node checkStart = this.nodes.get(start);
	Node checkEnd = this.nodes.get(end);

	SearchNode shortPath = computeShortestPath(checkStart, checkEnd);
        return shortPath.cost;
    }

    ////////////////////////////////////test//////////////////////////////////////////
    /**
    *  This lectureExampleTest checks if shortestPathCost() and
    *  shortestPathData() returns the same shortest path that
    *  we have done in class.
    *
    *  @returns true if the tests pass, else false
    */
    @Test
    public void lectureExampleTest() {
	//setting same as the lecture example
	DijkstraGraph<String, Integer> graph = new DijkstraGraph<>();
	graph.insertNode("A");
	graph.insertNode("B");
	graph.insertNode("C");
	graph.insertNode("D");
	graph.insertNode("E");
	graph.insertNode("F");
	graph.insertNode("G");
	graph.insertNode("H");
	graph.insertEdge("A", "B", 4);
	graph.insertEdge("A", "C", 2);
	graph.insertEdge("A", "E", 15);
	graph.insertEdge("B", "D", 1);
	graph.insertEdge("B", "E", 10);
	graph.insertEdge("C", "D", 5);
	graph.insertEdge("D", "E", 3);
	graph.insertEdge("D", "F", 0);
	graph.insertEdge("F", "D", 2);
	graph.insertEdge("F", "H", 4);
	graph.insertEdge("G", "H", 4);

	//checking the shortest path's cost
	double cost = graph.shortestPathCost("A", "E");
	assertEquals(8.0, cost);
	//checking the shortest path's path
	List<String> path = graph.shortestPathData("A", "E");
	assertNotNull(path);
	assertEquals(Arrays.asList("A", "B", "D", "E"), path);
    }

    /**
    *  This lectureExampleWithDifferentEndTest checks if shortestPathCost() and
    *  shortestPathData() return the correct shortest path from A to F
    *  using a different end node from the lecture example graph.
    *
    *  @return true if the tests pass, else false
    */
    @Test
    public void lectureExampleWithDifferentEndTest() {
	//setting same as the lecture example
	DijkstraGraph<String, Integer> graph = new DijkstraGraph<>();
	graph.insertNode("A");
	graph.insertNode("B");
	graph.insertNode("C");
	graph.insertNode("D");
	graph.insertNode("E");
	graph.insertNode("F");
	graph.insertNode("G");
	graph.insertNode("H");
	graph.insertEdge("A", "B", 4);
	graph.insertEdge("A", "C", 2);
	graph.insertEdge("A", "E", 15);
	graph.insertEdge("B", "D", 1);
	graph.insertEdge("B", "E", 10);
	graph.insertEdge("C", "D", 5);
	graph.insertEdge("D", "E", 3);
	graph.insertEdge("D", "F", 0);
	graph.insertEdge("F", "D", 2);
	graph.insertEdge("F", "H", 4);
	graph.insertEdge("G", "H", 4);

	//checking the shortest path's cost
	double cost = graph.shortestPathCost("A", "F");
	assertEquals(5.0, cost);

	//checking the shortest path's path
	List<String> path = graph.shortestPathData("A", "F");
	assertNotNull(path);
	assertEquals(Arrays.asList("A", "B", "D", "F"), path);
    }

    /**
    *  This behaviorTest checks if shortestPathCost() and
    *  shortestPathData() throw NoSuchElementException when no path exists
    *  or when either the start or end node does not exist.
    *
    *  @return true if the tests pass, else false
    */
    @Test
    public void behaviorTest() {
	//setting same as the lecture example
	DijkstraGraph<String, Integer> graph = new DijkstraGraph<>();
	graph.insertNode("A");
	graph.insertNode("B");
	graph.insertNode("C");
	graph.insertNode("D");
	graph.insertNode("E");
	graph.insertNode("F");
	graph.insertNode("G");
	graph.insertNode("H");
	graph.insertEdge("A", "B", 4);
	graph.insertEdge("A", "C", 2);
	graph.insertEdge("A", "E", 15);
	graph.insertEdge("B", "D", 1);
	graph.insertEdge("B", "E", 10);
	graph.insertEdge("C", "D", 5);
	graph.insertEdge("D", "E", 3);
	graph.insertEdge("D", "F", 0);
	graph.insertEdge("F", "D", 2);
	graph.insertEdge("F", "H", 4);
	graph.insertEdge("G", "H", 4);

	//checking behavior when no path exists from A to G
	assertThrows(NoSuchElementException.class, () -> { graph.shortestPathCost("A", "G"); });

	assertThrows(NoSuchElementException.class, () -> { graph.shortestPathData("A", "G"); });

	//checking behavior when the start node does not exist
	assertThrows(NoSuchElementException.class, () -> { graph.shortestPathCost("I", "E"); });

	//checking behavior when the end node does not exist
	assertThrows(NoSuchElementException.class, () -> { graph.shortestPathData("A", "I"); });
    }

}
