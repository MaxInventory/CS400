import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

public class FrontendTests {

    /**
     * This roleTest1 checks if generateShortestPathPromptHTML() contains
     * text input fields with the correct id, and correct button label
     * 
     * @return true if the tests pass, else false
     */
    @Test
    public void roleTest1() {
	GraphADT<String,Double> graph = new Graph_Placeholder();
        BackendInterface backend = new Backend_Placeholder(graph);
        Frontend frontend = new Frontend(backend);

        String html = frontend.generateShortestPathPromptHTML();

        assertTrue(html.contains("id=\"start\""));
        assertTrue(html.contains("id=\"end\""));
        assertTrue(html.contains("Start Location"));
        assertTrue(html.contains("End Location"));
        assertTrue(html.contains("Find Shortest Path"));
    }

    /**
     * This roleTest2 checks if generateShortestPathResponseHTML(start, end) contains
     * total time and list of locations in order.
     * 
     * @return true if the tests pass, else false
     */
    @Test
    public void roleTest2() {
        GraphADT<String,Double> graph = new Graph_Placeholder();
	BackendInterface backend = new Backend_Placeholder(graph);
        Frontend frontend = new Frontend(backend);

        String start = "A";
        String end = "E";

        List<String> locations = backend.findLocationsOnShortestPath(start, end);
        List<Double> times = backend.findTimesOnShortestPath(start, end);

        String html = frontend.generateShortestPathResponseHTML(start, end);

        if (locations == null || locations.size() == 0) {
            assertTrue(html.contains("<p>"));
        } else {
            assertTrue(html.contains("<p>"));
            assertTrue(html.contains("<ol>"));
            assertTrue(html.contains("</ol>"));
            assertTrue(html.contains("Total time:"));

            for (String location : locations) {
                assertTrue(html.contains(location));
            }

            double total = 0.0;
            if (times != null) {
                for (Double time : times) {
                    total += time;
                }
            }
            assertTrue(html.contains("" + total));
        }
    }

    /**
     * This roleTest3 checks if generateReachableFromWithinResponseHTML(start, maxTime)
     * contains the correct text input fields, button labels, and the elements that
     * response HTML have to include
     * 
     * @return true if the tests pass, else false
     */
    @Test
    public void roleTest3() {
	GraphADT<String,Double> graph = new Graph_Placeholder();
        BackendInterface backend = new Backend_Placeholder(graph);
        Frontend frontend = new Frontend(backend);

        String promptHTML = frontend.generateReachableFromWithinPromptHTML();
        assertTrue(promptHTML.contains("id=\"from\""));
        assertTrue(promptHTML.contains("id=\"time\""));
        assertTrue(promptHTML.contains("Start Location"));
        assertTrue(promptHTML.contains("Max Time"));
        assertTrue(promptHTML.contains("Reachable From Within"));

        String start = "A";
        double maxTime = 60.0;
        String responseHTML = frontend.generateReachableFromWithinResponseHTML(start, maxTime);

        assertTrue(responseHTML.contains("<p>") || responseHTML.contains("<ul>"));

        try {
            List<String> locations = backend.getReachableFromWithin(start, maxTime);

            if (locations == null || locations.size() == 0) {
                assertTrue(responseHTML.contains("No locations") || responseHTML.contains("Error"));
            } else {
                assertTrue(responseHTML.contains("<ul>"));
                assertTrue(responseHTML.contains("</ul>"));
                for (String location : locations) {
                    assertTrue(responseHTML.contains(location));
                }
            }
        } catch (Exception e) {
            assertTrue(responseHTML.contains("Error"));
        }
    }
}
