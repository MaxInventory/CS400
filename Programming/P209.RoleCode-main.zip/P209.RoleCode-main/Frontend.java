import java.util.List;
import java.util.NoSuchElementException;

/**
*  The Frontend class implements FrontendInterface.
*  This class contains methods that generates Prompt and Responses about shortest path,
*  and which locations are reachable within a given time
*/
public class Frontend implements FrontendInterface {

	//Data field
	private BackendInterface backend;

	//Constructor
	public Frontend(BackendInterface backend) {
		this.backend = backend;
	}

	/**
	*  This method generates the shortest path prompt in HTML.
	*  The prompt includes labeled input fields: start and end locations (each with proper ids).
	*  Along with a button to find shortest path
	*
	*  @return html that includes the shortest path prompt
	*/
	@Override
	public String generateShortestPathPromptHTML() {
		StringBuilder html = new StringBuilder();

		html.append("<label for=\"start\">Start Location:</label>\n");
         	html.append("<input type=\"text\" id=\"start\">\n");
         	html.append("<label for=\"end\">End Location:</label>\n");
         	html.append("<input type=\"text\" id=\"end\">\n");
         	html.append("<button>Find Shortest Path</button>\n");

		return html.toString();
	}

	/**
 	* This helper Method check if the string is null or empty.
 	*
 	* @param string String to be checked
 	* @return true if the input is null or empty, else false
 	*/
	private boolean isEmptyOrNull(String string) {
		return string == null || string.trim().isEmpty();
	}

	/**
	* This helper method filters the string to be safe to use
	*
	* @param string String that need to be filtered
	* @return safe version to be used for html
 	*/
	private String filteredHTML(String string) {
	if (string == null) {
		return "";
	}

	return string.replace("&", "&amp;")
		     .replace("<", "&lt;")
		     .replace(">", "&gt;")
		     .replace("\"", "&quot;")
		     .replace("'", "&#39;");
	}

	/**
	*  This method generates the shortest path response in HTML.
	*  The response includes description of the route, a list of locations in order,
	*  and the total time it took.
	*
	*  @param start the starting location
	*  @param end the ending location
	*  @return html that includes the shortest path response
	*/
	@Override
	public String generateShortestPathResponseHTML(String start, String end) {
		if (isEmptyOrNull(start) || isEmptyOrNull(end)) {
			return "<p>Error: Either Start or End location is empty.</p>\n";
		}

		String filteredStart = filteredHTML(start);
		String filteredEnd = filteredHTML(end);

		try {
			List<String> locations = backend.findLocationsOnShortestPath(start, end);
			List<Double> times = backend.findTimesOnShortestPath(start,end);
			if (locations == null || locations.size() == 0) {
				return "<p>No path exists from " + start + " to " + end + ".</p>\n";
			}
			double total = 0.0;
			if (times != null) {
                		for (Double time : times) {
                    			total += time;
                		}
            		}

			StringBuilder html = new StringBuilder();

			html.append("<p>Shortest path from ").append(filteredStart).append(" to ").append(filteredEnd).append(":</p>\n");

			html.append("<ol>\n");

			for (String location : locations) {
				html.append(" <li>").append(filteredHTML(location)).append("</li>\n");
			}

			html.append("</ol>\n");
			html.append("<p>Total time: ").append(total).append(" minutes</p>\n");

			return html.toString();
		}catch (NoSuchElementException e) {
			return "<p>Error: Either one of the locations or both of them cannot be found.</p>\n";
		}catch (Exception e) {
			return "<p>Error: An error have occured.</p>\n";
		}

    	}

	/**
	*  This method generate reachable from within prompt.
		*  The prompt includes labeled input fields: starting location and max time (each with proper ids).
	*  Along with a button to find if it is reachable
	*
	*  @return html that includes the reachable from within prompt
	*/
    	@Override
    	public String generateReachableFromWithinPromptHTML() {
        	StringBuilder html = new StringBuilder();

            	html.append("<label for=\"from\">Start Location:</label>\n");
            	html.append("<input type=\"text\" id=\"from\">\n");
            	html.append("<label for=\"time\">Max Time:</label>\n");
            	html.append("<input type=\"text\" id=\"time\">\n");
            	html.append("<button>Reachable From Within</button>\n");

        	return html.toString();
    	}

	/**
	*  This method generate reachable from within response.
	*  The response includes description of which locations are reachable within the given maxTime.
	*  If no locations are reachable or an error occurs, a message is returned instead.
	*
	*  @param start the start location
	*  @param maxTime the maximum time allowed for traveling
	*  @return html that includes the reachable from within response
	*/
    	@Override
    	public String generateReachableFromWithinResponseHTML(String start, double maxTime) {
		if (isEmptyOrNull(start)) {
			return "<p>Error: Either Start or End location is empty.</p>\n";
		}

		if (maxTime < 0) {
			return "<p>Error: maxTime is negative.</p>\n";
		}

		String filteredStart = filteredHTML(start);
		StringBuilder html = new StringBuilder();

        	try {
            		List<String> locations = backend.getReachableFromWithin(start, maxTime);

	        	if (locations == null || locations.size() == 0) {
                		html.append("<p>No locations reachable from ").append(start).append(" within ").append(maxTime).append(" minutes.</p>\n");
                		return html.toString();
            		}

            		html.append("<p>Locations reachable from ").append(filteredStart).append(" within ").append(maxTime).append(" minutes:</p>\n");
            		html.append("<ul>\n");

            		for (String location : locations) {
                		html.append("<li>").append(filteredHTML(location)).append("</li>\n");
            		}

            		html.append("</ul>\n");
		} catch (NoSuchElementException e) {
			return "<p>Error: The start location cannot be found.</p>\n";
            	} catch (Exception e) {
            		return "<p>Error: An error have occured.</p>\n";
            	}
        	return html.toString();
    		}

	}

