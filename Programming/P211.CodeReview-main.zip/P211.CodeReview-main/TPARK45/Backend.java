import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.io.File;
import java.util.Scanner;

/**
 * This class makes use of a GraphADT to perform shortest path computations.
 */
public class Backend implements BackendInterface {

    private GraphADT<String, Double> graph;
    private List<String> nodes;

    /*
     * Constructor
     * 
     * @param graph object to store the backend's graph data
     */
    public Backend(GraphADT<String, Double> graph) {
        this.graph = graph;
        this.nodes = new ArrayList<>();
    }

    /**
     * Loads graph data from a dot file. If a graph was previously loaded, this
     * method should first delete the contents (nodes and edges) of the existing
     * graph before loading a new one.
     * 
     * @param filename the path to a dot file to read graph data from
     * @throws IOException if there was any problem reading from this file
     */
    public void loadGraphData(String filename) throws IOException {
        for (String node : nodes) { // clear the graph if there are previous nodes
            graph.removeNode(node);
        }
        nodes.clear();

        File file = new File(filename);
        try (Scanner sc = new Scanner(file)) {
            while (sc.hasNextLine()) {
                String line = sc.nextLine().trim();
                // Check if the line represents an edge
                if (line.contains("->") && line.contains("[minutes=")) {
                    int firstQuote = line.indexOf("\"");
                    int secondQuote = line.indexOf("\"", firstQuote + 1);
                    if (firstQuote != -1 && secondQuote != -1) { // if found, extract source
                        String source = line.substring(firstQuote + 1, secondQuote);

                        int thirdQuote = line.indexOf("\"", secondQuote + 1);
                        int fourthQuote = line.indexOf("\"", thirdQuote + 1);
                        if (thirdQuote != -1 && fourthQuote != -1) { // if found, extract destination
                            String dest = line.substring(thirdQuote + 1, fourthQuote);

                            int minStart = line.indexOf("[minutes=") + 9;
                            int minEnd = line.indexOf("]", minStart);
                            if (minStart != -1 && minEnd != -1) { // if found, extract minutes
                                String weightStr = line.substring(minStart, minEnd);
                                try {
                                    double weight = Double.parseDouble(weightStr);

                                    if (!nodes.contains(source)) { // if node isn't in the list, add it
                                        nodes.add(source);
                                        graph.insertNode(source);
                                    }
                                    if (!nodes.contains(dest)) { // if node isn't in the list, add it
                                        nodes.add(dest);
                                        graph.insertNode(dest);
                                    }
                                    graph.insertEdge(source, dest, weight); // insert edge
                                } catch (NumberFormatException e) { // if number parsing fails, skip line
                                    continue;
                                }
                            }
                        }
                    }
                }
            }
        } catch (IOException e) {
            throw e;
        }
    }

    /**
     * Returns a list of all locations in the graph.
     * 
     * @return list of all location names
     */
    public List<String> getListOfAll() {
        return new ArrayList<>(nodes);
    }

    /**
     * Return the sequence of locations along the shortest path from start to
     * end, or an empty list if no such path exists.
     * 
     * @param start the start of the path
     * @param end   the end of the path
     * @return a list with the nodes along the shortest path from start to end,
     *         or an empty list if no such path exists
     */
    public List<String> findLocationsOnShortestPath(String start, String end) {
        try {
            return graph.shortestPathData(start, end);
        } catch (NoSuchElementException e) {
            return new ArrayList<>();
        }
    }

    /**
     * Return the times in minutes between each two nodes on the shortest path
     * from start to end, or an empty list if no such path exists.
     * 
     * @param start the start of the path
     * @param end   the end of the path
     * @return a list with the times in minutes between two nodes along the
     *         shortest path from start to end, or an empty list if no such path
     *         exists
     */
    public List<Double> findTimesOnShortestPath(String start, String end) {
        List<Double> times = new ArrayList<>();
        try {
            List<String> path = graph.shortestPathData(start, end);
            for (int i = 0; i < path.size() - 1; i++) {
                times.add(graph.getEdge(path.get(i), path.get(i + 1)));
            }
        } catch (NoSuchElementException e) {
            // Path does not exist or nodes not found
        }
        return times;
    }

    /**
     * Returns the list of locations that can be reached when starting from the
     * provided start, and travelling maxTime in minutes.
     * 
     * @param start   the location to find the reachable locations from
     * @param maxTime is the maximum time it can take to get from from the
     *                start to report a location
     * @return the list of locations that can be reached from start in maxTime
     *         or fewer minutes
     * @throws NoSuchElementException if start does not exist
     */
    public List<String> getReachableFromWithin(String start, double maxTime) throws NoSuchElementException {
        if (!graph.containsNode(start)) {
            throw new NoSuchElementException("Start node does not exist in graph");
        }

        List<String> reachable = new ArrayList<>();
        for (String node : nodes) {
            if (node.equals(start)) { // if the node is start node, add to reachable nodes
                reachable.add(node);
                continue;
            }
            try {
                if (graph.shortestPathCost(start, node) <= maxTime) { // if the node is reachable within maxTime, add to reachable nodes
                    reachable.add(node);
                }
            } catch (NoSuchElementException e) {
                // Ignore unreachable nodes
            }
        }
        return reachable;
    }
}
