import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

/**
 * This is the backend class that implements BackendInterface. It makes use of
 * a GraphADT to perform shortest path computations.
 */
public class Backend implements BackendInterface {

    // graph object to store locations and walking times
    private GraphADT<String, Double> graph;
    // keeps track of all locations we added so we can list them later
    private List<String> allLocations;

    /**
     * constructor that takes a graph object to store data
     * @param graph object to store the backend's graph data
     */
    public Backend(GraphADT<String, Double> graph) {
        this.graph = graph;
        this.allLocations = new ArrayList<>();
    }

    /**
     * Loads graph data from a dot file. If a graph was previously loaded, this
     * method should first delete the contents (nodes and edges) of the existing
     * graph before loading a new one.
     * @param filename the path to a dot file to read graph data from
     * @throws IOException if there was any problem reading from this file
     */
    @Override
    public void loadGraphData(String filename) throws IOException {
        // clear existing data first
        for (String location : new ArrayList<>(allLocations)) {
            graph.removeNode(location);
        }
        allLocations.clear();

        // read the dot file line by line
        BufferedReader reader = new BufferedReader(new FileReader(filename));
        String line;

        while ((line = reader.readLine()) != null) {
            line = line.trim();

            // skip empty lines and graph declaration lines
            if (line.isEmpty() || line.startsWith("digraph") || line.equals("{") || line.equals("}")) {
                continue;
            }

            // parse edge lines like: "NodeA" -> "NodeB" [seconds=123.4]
            if (line.contains("->")) {
                // extract the two node names and the edge weight
                String[] parts = line.split("->");
                String predNode = extractNodeName(parts[0]);
                
                // second part has successor and weight
                String remaining = parts[1];
                int bracketStart = remaining.indexOf("[");
                String succNode = extractNodeName(remaining.substring(0, bracketStart));
                
                // get the weight from seconds=X.X part
                double weight = extractWeight(remaining);

                // add nodes if they dont exist yet
                if (!allLocations.contains(predNode)) {
                    graph.insertNode(predNode);
                    allLocations.add(predNode);
                }
                if (!allLocations.contains(succNode)) {
                    graph.insertNode(succNode);
                    allLocations.add(succNode);
                }

                // add the edge
                graph.insertEdge(predNode, succNode, weight);
            }
        }
        reader.close();
    }

    /**
     * helper to pull out node name from quotes
     * @param raw the raw string containing quoted node name
     * @return the node name without quotes
     */
    private String extractNodeName(String raw) {
        raw = raw.trim();
        int firstQuote = raw.indexOf("\"");
        int lastQuote = raw.lastIndexOf("\"");
        if (firstQuote != -1 && lastQuote != -1 && firstQuote != lastQuote) {
            return raw.substring(firstQuote + 1, lastQuote);
        }
        return raw;
    }

    /**
     * helper to get the seconds value from bracket part
     * @param bracketPart string containing [seconds=X.X]
     * @return the weight as double
     */
    private double extractWeight(String bracketPart) {
        int eqSign = bracketPart.indexOf("=");
        int endBracket = bracketPart.indexOf("]");
        if (eqSign != -1 && endBracket != -1) {
            String numStr = bracketPart.substring(eqSign + 1, endBracket).trim();
            return Double.parseDouble(numStr);
        }
        return 0.0;
    }

    /**
     * Returns a list of all locations in the graph.
     * @return list of all location names
     */
    @Override
    public List<String> getListOfAll() {
        return new ArrayList<>(allLocations);
    }

    /**
     * Return the sequence of locations along the shortest path from start to 
     * end, or an empty list if no such path exists.
     * @param start the start of the path
     * @param end the end of the path
     * @return a list with the nodes along the shortest path from start to end,
     *         or an empty list if no such path exists
     */
    @Override
    public List<String> findLocationsOnShortestPath(String start, String end) {
        try {
            return graph.shortestPathData(start, end);
        } catch (NoSuchElementException e) {
            // no path exists so return empty
            return new ArrayList<>();
        }
    }

    /**
     * Return the times in minutes between each two nodes on the shortest path 
     * from start to end, or an empty list if no such path exists.
     * @param start the start of the path
     * @param end the end of the path
     * @return a list with the times in minutes between two nodes along the 
     * shortest path from start to end, or an empty list if no such path exists
     */
    @Override
    public List<Double> findTimesOnShortestPath(String start, String end) {
        List<String> path = findLocationsOnShortestPath(start, end);
        List<Double> times = new ArrayList<>();

        // if path is empty or just one node theres no edges
        if (path.size() < 2) {
            return times;
        }

        // go through consecutive pairs and get each edge weight
        for (int i = 0; i < path.size() - 1; i++) {
            try {
                Double edgeWeight = graph.getEdge(path.get(i), path.get(i + 1));
                times.add(edgeWeight);
            } catch (NoSuchElementException e) {
                // edge not found which shouldnt happen but handle it anyway
                times.add(0.0);
            }
        }

        return times;
    }

    /**
     * Returns the list of locations that can be reached when starting from the 
     * provided start, and travelling maxTime in minutes.
     * @param start the location to find the reachable locations from
     * @param maxTime is the maximum time it can take to get from from the 
     * start to report a location
     * @return the list of locations that can be reached from start in maxTime 
     * or fewer minutes
     * @throws NoSuchElementException if start does not exist
     */
    @Override
    public List<String> getReachableFromWithin(String start, double maxTime) throws NoSuchElementException {
        // check if start location exists
        if (!graph.containsNode(start)) {
            throw new NoSuchElementException("start location not found: " + start);
        }

        List<String> reachable = new ArrayList<>();

        // check every location to see if we can reach it in time
        for (String location : allLocations) {
            try {
                double cost = graph.shortestPathCost(start, location);
                if (cost <= maxTime) {
                    reachable.add(location);
                }
            } catch (NoSuchElementException e) {
                // cant reach this location so skip it
            }
        }

        return reachable;
    }
}

