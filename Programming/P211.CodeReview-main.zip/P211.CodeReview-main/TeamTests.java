import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

public class TeamTests {

    /**
     * Helper method that creates a backend.
     *
     * @return a backend object
     */
    private BackendInterface createBackend() {
        GraphADT<String, Double> graph = new TestGraph();
        BackendInterface backend = new Backend(graph);
        return backend;
    }

    /**
     * Helper method that creates a temporary file (.dot).
     *
     * @param data Data used to change into a file
     * @return Path to the file
     * @throws IOException if writing or creating a file gets an error
     */
    private String createFile(String data) throws IOException {
        File tempFile = File.createTempFile("graph", ".dot");
        tempFile.deleteOnExit();

        FileWriter writer = new FileWriter(tempFile);
        writer.write(data);
        writer.close();

        return tempFile.getAbsolutePath();
    }

    /**
     * This loadGraphDataTest checks if loadGraphData() load all locations
     * and getListOfAll() returns the locations.
     *
     * @throws Exception if loading or creating a file gets an error
     */
    @Test
    public void loadGraphDataTest() throws Exception {
        BackendInterface backend = createBackend();

        String graph =
            "digraph {\n" +
            "\"A\" -> \"B\" [minutes=2.0];\n" +
            "\"B\" -> \"C\" [minutes=3.0];\n" +
            "\"A\" -> \"C\" [minutes=10.0];\n" +
            "\"D\" -> \"E\" [minutes=1.0];\n" +
            "}\n";

        String filePath = createFile(graph);

        // Loading the graph into the backend.
        backend.loadGraphData(filePath);

        // Getting all of the locations from the backend.
        List<String> locations = backend.getListOfAll();

        // Checking if the locations are contained.
        assertTrue(locations.contains("A"));
        assertTrue(locations.contains("B"));
        assertTrue(locations.contains("C"));
        assertTrue(locations.contains("D"));
        assertTrue(locations.contains("E"));
    }

    /**
     * This findLocationsOnShortestPathTest checks if findLocationsOnShortestPath()
     * returns the correct shortest path & in order.
     *
     * @throws Exception if the file cannot be created or loaded
     */
    @Test
    public void findLocationsOnShortestPathTest() throws Exception {
        BackendInterface backend = createBackend();

        String graph =
            "digraph {\n" +
            "\"A\" -> \"B\" [minutes=2.0];\n" +
            "\"B\" -> \"C\" [minutes=3.0];\n" +
            "\"A\" -> \"C\" [minutes=10.0];\n" +
            "\"D\" -> \"E\" [minutes=1.0];\n" +
            "}\n";

        String filename = createFile(graph);
        backend.loadGraphData(filename);

        // Find the shortest path from (A -> C).
        List<String> path = backend.findLocationsOnShortestPath("A", "C");

        // The shortest path should be A -> B -> C.
        assertEquals(Arrays.asList("A", "B", "C"), path);
    }

    /**
     * This findTimesOnShortestPathTest checks if findTimesOnShortestPath(start, end)
     * returns the correct edge weights in order along the shortest path.
     *
     * @throws Exception if the file cannot be created or loaded
     */
    @Test
    public void findTimesOnShortestPathTest() throws Exception {
        BackendInterface backend = createBackend();

        String graph =
            "digraph {\n" +
            "\"A\" -> \"B\" [minutes=2.0];\n" +
            "\"B\" -> \"C\" [minutes=3.0];\n" +
            "\"A\" -> \"C\" [minutes=10.0];\n" +
            "\"D\" -> \"E\" [minutes=1.0];\n" +
            "}\n";

        String filename = createFile(graph);
        backend.loadGraphData(filename);

        // Get the times along the shortest path from (A -> C).
        List<Double> times = backend.findTimesOnShortestPath("A", "C");

        // Check if the shortest path is A -> B -> C, and the times should be 2.0 and 3.0.
        assertEquals(2, times.size());
        assertEquals(2.0, times.get(0), 0.0001);
        assertEquals(3.0, times.get(1), 0.0001);
    }

    /**
     * This getReachableTest checks if getReachableFromWithin(start, maxTime)
     * includes reachable locations and excludes unreachable ones.
     *
     * @throws Exception if the file cannot be created or loaded
     */
    @Test
    public void getReachableTest() throws Exception {
        BackendInterface backend = createBackend();

        String graph =
            "digraph {\n" +
            "\"A\" -> \"B\" [minutes=2.0];\n" +
            "\"B\" -> \"C\" [minutes=3.0];\n" +
            "\"A\" -> \"C\" [minutes=10.0];\n" +
            "\"D\" -> \"E\" [minutes=1.0];\n" +
            "}\n";

        String filename = createFile(graph);
        backend.loadGraphData(filename);

        // Get all locations reachable from A within 5 minutes.
        List<String> reachable = backend.getReachableFromWithin("A", 5.0);

        // B and C is reachable, but X and Y aren't
        assertTrue(reachable.contains("B"));
        assertTrue(reachable.contains("C"));
        assertFalse(reachable.contains("D"));
        assertFalse(reachable.contains("E"));
    }

    /**
     * I have created this TestGraph to use it for consistent testing quality.
     */
    private static class TestGraph implements GraphADT<String, Double> {
        
        private Map<String, Map<String, Double>> edges =
            new HashMap<String, Map<String, Double>>();

        public boolean insertNode(String node) {
            if (edges.containsKey(node)) {
                return false;
            }
            edges.put(node, new HashMap<String, Double>());
            return true;
        }

        public boolean removeNode(String node) {
            if (!edges.containsKey(node)) {
                return false;
            }

            edges.remove(node);

            for (String nodes : edges.keySet()) {
                edges.get(nodes).remove(node);
            }
            return true;
        }

        public boolean containsNode(String node) {
            return edges.containsKey(node);
        }

        public int getNodeCount() {
            return edges.size();
        }

        public boolean insertEdge(String prev, String next, Double weight) {
            if (!edges.containsKey(prev) || !edges.containsKey(next)) {
                throw new NoSuchElementException();
            }

            boolean isNewEdge = !edges.get(prev).containsKey(next);
            edges.get(prev).put(next, weight);
            return isNewEdge;
        }

        public boolean removeEdge(String prev, String next) {
            if (!edges.containsKey(prev)) {
                return false;
            }
            return edges.get(prev).remove(next) != null;
        }

        public boolean containsEdge(String prev, String next) {
            return edges.containsKey(prev) && edges.get(prev).containsKey(next);
        }

        public Double getEdge(String prev, String next) {
            if (!containsEdge(prev, next)) {
                throw new NoSuchElementException();
            }
            return edges.get(prev).get(next);
        }

        public int getEdgeCount() {
            int count = 0;
            for (String node : edges.keySet()) {
                count += edges.get(node).size();
            }
            return count;
        }

        public List<String> shortestPathData(String start, String end) {
            Search result = runDijkstra(start, end);
            return result.path;
        }

        public double shortestPathCost(String start, String end) {
            Search result = runDijkstra(start, end);
            return result.cost;
        }

        /**
         * This helper method runs Dijkstra's algorithm.
         * Made to check which code is more suitable for my frontend code.
         *
         * @param start the starting node
         * @param end the ending node
         * @return the shortest path and its cost
         */
        private Search runDijkstra(String start, String end) {
            if (!containsNode(start) || !containsNode(end)) {
                throw new NoSuchElementException();
            }

            Map<String, Double> distance = new HashMap<String, Double>();
            Map<String, String> previous = new HashMap<String, String>();
            List<String> visited = new ArrayList<String>();

            for (String node : edges.keySet()) {
                distance.put(node, -1.0);
            }
            distance.put(start, 0.0);

            while (visited.size() < edges.size()) {
                String current = null;
                double bestDistance = -1.0;

                for (String node : edges.keySet()) {
                    if (!visited.contains(node)) {
                        double currentDistance = distance.get(node);

                        if (currentDistance != -1.0) {
                            if (bestDistance == -1.0 || currentDistance < bestDistance) {
                                bestDistance = currentDistance;
                                current = node;
                            }
                        }
                    }
                }

                if (current == null) {
                    break;
                }

                visited.add(current);

                for (String neighbor : edges.get(current).keySet()) {
                    if (!visited.contains(neighbor)) {
                        double newCost = distance.get(current) + edges.get(current).get(neighbor);
                        double oldCost = distance.get(neighbor);

                        if (oldCost == -1.0 || newCost < oldCost) {
                            distance.put(neighbor, newCost);
                            previous.put(neighbor, current);
                        }
                    }
                }
            }

            if (distance.get(end) == -1.0) {
                throw new NoSuchElementException();
            }

            List<String> path = new ArrayList<String>();
            String current = end;

            while (current != null) {
                path.add(current);
                current = previous.get(current);
            }

            Collections.reverse(path);
            return new Search(path, distance.get(end));
        }
    }

        /**
         * This Search class is made to check the cost and path
         */
        private static class Search {
        List<String> path;
        double cost;

        Search(List<String> path, double cost) {
            this.path = path;
            this.cost = cost;
        }
    }
}
