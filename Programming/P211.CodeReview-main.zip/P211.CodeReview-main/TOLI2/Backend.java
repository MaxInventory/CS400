import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.io.File;
import java.util.Scanner;

/**
 * This is the interface that a backend developer will implement, so that a
 * frontend developer's code can make use of this functionality. It makes use of
 * a GraphADT to perform shortest path computations.
 */
public class Backend implements BackendInterface {
   
    private GraphADT<String, Double> graph;
    private List<String> locations;

    /**
     * Backend constructor that sets the graph instance variable
     * @param graph a GraphADT that stores nodes(locations) and weights(time) to
     * help calculate path costs
     */
    public Backend(GraphADT<String, Double> graph) {
        if (graph == null) {
            throw new IllegalArgumentException();
        }
        this.graph = graph;
        locations = new ArrayList<>();
    }

    /**
     * Loads graph data from a dot file. If a graph was previously loaded, this
     * method should first delete the contents (nodes and edges) of the existing
     * graph before loading a new one.
     * @param filename the path to a dot file to read graph data from
     * @throws IOException if there was any problem reading from this file
     */
    public void loadGraphData(String filename) throws IOException {
        //Clears through existing graph data
        for (String location : locations) {
            graph.removeNode(location);
        }
        //Resets the location array
        locations = new ArrayList<>();
        try (Scanner sc = new Scanner(new File(filename))) {
            while (sc.hasNextLine()) {
                String line = sc.nextLine().trim();
                //skips irrelevant lines in file
                if (line.isEmpty() || line.startsWith("digraph") 
                    || line.equals("{") || line.equals("}")) {
                    continue;
                }
                //Processes each line and inserts it nodes and edges into graph
                try {
                    String[] data = line.replace("\"", "").split("\\[");
                    String nodes = data[0];
                    Double weight = Double.parseDouble(data[1].replace("minutes=", "").replace("];", "").trim());
                    String[] nodeArr = nodes.split("->");
                    String pred = nodeArr[0].trim();
                    String succ = nodeArr[1].trim();
                    graph.insertNode(pred);
                    graph.insertNode(succ);
                    if (!locations.contains(pred)) {
                        locations.add(pred);
                    }
                    if (!locations.contains(succ)) {
                        locations.add(succ);
                    }
                    graph.insertEdge(pred, succ, weight);
                } catch (Exception e) {
                    throw new IOException("Error parsing line: " + line, e);
                }
            }
        }
    }

    /**
     * Returns a list of all locations in the graph.
     * @return list of all location names
     */
    public List<String> getListOfAll() {
        return locations;
    }

    /**
     * Return the sequence of locations along the shortest path from start to 
     * end, or an empty list if no such path exists.
     * @param start the start of the path
     * @param end the end of the path
     * @return a list with the nodes along the shortest path from start to end,
     *         or an empty list if no such path exists
     */
    public List<String> findLocationsOnShortestPath(String start, String end) {
        return graph.shortestPathData(start, end);
    }

    /**
     * Return the times in minutes between each two nodes on the shortest path 
     * from start to end, or an empty list if no such path exists.
     * @param start the start of the path
     * @param end the end of the path
     * @return a list with the times in minutes between two nodes along the 
     * shortest path from start to end, or an empty list if no such path exists
     */
    public List<Double> findTimesOnShortestPath(String start, String end){
        List<String> path = graph.shortestPathData(start, end);
        List<Double> pathTimes = new ArrayList<Double>();
        //Iterates through a path array and finds and adds the time between
        //nodes into an array
        for (int i = 0; i < path.size() - 1; i++) {
            String pred = path.get(i);
            String succ = path.get(i + 1);
            pathTimes.add((Double)graph.getEdge(pred, succ));
        }
        return pathTimes;
    }

    /**
     * Returns the list of locations that can be reached when starting from the 
     * provided start, and travelling maxTime in minutes.
     * @param start the location to find the reachable locations from
     * @param maxTime is the maximum time it can take to get from from the 
     * start to report a location
     * @return the list of locations that can be reached from start in maxTime 
     * or fewer minutes
     * @throws NoSuchElementException if start does not exist
     */
    public List<String> getReachableFromWithin(String start, double maxTime) throws NoSuchElementException {
        List<String> reachable = new ArrayList<>();
        //Iterate through each location to see if it is reachable
        for(String location : locations) {
            //If the destination is equal to the start skip it
            if (location.equals(start)) continue;
            List<String> path = graph.shortestPathData(start, location);
            //Checks if a path exists and if the last element in the path is the desired destination
            if (path.size() <= 1 || !path.get(path.size() - 1).equals(location)) continue;
            //Checks if the path meets the time constrained and then is added result array
            if (graph.shortestPathCost(start, location) <= maxTime) {
                reachable.add(location);
            }
        }
        return reachable;
    }
}
