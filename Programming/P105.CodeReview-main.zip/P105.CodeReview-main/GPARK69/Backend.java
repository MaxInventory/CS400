import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Backend implements BackendInterface {
  private final IterableSortedCollection<GameRecord> tree;
  private Integer minCollectables;
  private Integer maxCollectables;
  private GameRecord.Continent continentFilter;
  private boolean rangeSet;

  /**
   * Stores records in the provided sorted collection and initializes with no active range or
   * continent filter.
   */
  public Backend(IterableSortedCollection<GameRecord> tree) {
    this.tree = tree;
    this.minCollectables = null;
    this.maxCollectables = null;
    this.continentFilter = null;
    this.rangeSet = false;
  }

  /**
   * Adds a record to the sorted tree. Null records are ignored.
   */
  @Override
  public void addRecord(GameRecord record) {
    if (record == null) {
      return;
    }
    tree.insert(record);
  }

  /**
   * Updates the active collectables range, configures iterator bounds, and returns names that
   * match both range and current continent filter.
   */
  @Override
  public List<String> getAndSetRange(Integer low, Integer high) {
    this.minCollectables = low;
    this.maxCollectables = high;
    this.rangeSet = true;

    if (low == null) {
      tree.setIteratorMin(null);
    } else {
      tree.setIteratorMin(createBoundaryRecord(low));
    }

    if (high == null) {
      tree.setIteratorMax(null);
    } else {
      tree.setIteratorMax(createBoundaryRecord(high));
    }

    return getFilteredNamesFromCurrentIteratorRange();
  }

  /**
   * Updates the active continent filter and returns names visible under the current range.
   */
  @Override
  public List<String> applyAndSetFilter(GameRecord.Continent continent) {
    this.continentFilter = continent;

    if (rangeSet) {
      tree.setIteratorMin(minCollectables == null ? null : createBoundaryRecord(minCollectables));
      tree.setIteratorMax(maxCollectables == null ? null : createBoundaryRecord(maxCollectables));
    } else {
      tree.setIteratorMin(null);
      tree.setIteratorMax(null);
    }

    return getFilteredNamesFromCurrentIteratorRange();
  }

  /**
   * Returns up to ten names from the active range/filter, ordered by fastest completion time.
   */
  @Override
  public List<String> getTopTen() {
    if (rangeSet) {
      tree.setIteratorMin(minCollectables == null ? null : createBoundaryRecord(minCollectables));
      tree.setIteratorMax(maxCollectables == null ? null : createBoundaryRecord(maxCollectables));
    } else {
      tree.setIteratorMin(null);
      tree.setIteratorMax(null);
    }

    List<GameRecord> candidates = new ArrayList<>();
    for (GameRecord record : tree) {
      if (record != null && passesContinentFilter(record)) {
        candidates.add(record);
      }
    }

    candidates.sort(Comparator
        .comparingInt((GameRecord r) -> parseCompletionTimeToSeconds(r.getCompletionTime()))
        .thenComparing(GameRecord::getName));

    List<String> topTen = new ArrayList<>();
    int limit = Math.min(10, candidates.size());
    for (int i = 0; i < limit; i++) {
      topTen.add(candidates.get(i).getName());
    }
    return topTen;
  }

  /**
   * Reads records from CSV by header name, extracting only required backend columns.
   */
  @Override
  public void readData(String filename) throws IOException {
    if (filename == null || filename.trim().isEmpty()) {
      throw new IOException("filename must not be null or empty");
    }

    try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
      String headerLine = reader.readLine();
      if (headerLine == null) {
        return;
      }

      String[] headers = splitCsvLine(headerLine);
      Map<String, Integer> indexMap = new HashMap<>();
      for (int i = 0; i < headers.length; i++) {
        indexMap.put(headers[i].trim().toLowerCase(), i);
      }

      int nameIdx = requiredIndex(indexMap, "name");
      int continentIdx = requiredIndex(indexMap, "continent");
      int scoreIdx = requiredIndex(indexMap, "score");
      int maxHealthIdx = requiredIndex(indexMap, "max_health");
      int collectablesIdx = requiredIndex(indexMap, "collectables");
      int completionTimeIdx = requiredIndex(indexMap, "completion_time");

      String line;
      while ((line = reader.readLine()) != null) {
        if (line.trim().isEmpty()) {
          continue;
        }

        String[] tokens = splitCsvLine(line);

        try {
          String name = getToken(tokens, nameIdx);
          GameRecord.Continent continent = GameRecord.Continent.valueOf(getToken(tokens, continentIdx));
          int score = Integer.parseInt(getToken(tokens, scoreIdx));
          int maxHealth = Integer.parseInt(getToken(tokens, maxHealthIdx));
          int collectables = Integer.parseInt(getToken(tokens, collectablesIdx));
          String completionTime = getToken(tokens, completionTimeIdx);

          GameRecord record =
              new GameRecord(name, continent, score, maxHealth, collectables, completionTime);
          addRecord(record);
        } catch (IllegalArgumentException e) {
          // Skip malformed data rows and continue processing remaining lines.
        }
      }
    }
  }

  private List<String> getFilteredNamesFromCurrentIteratorRange() {
    List<String> names = new ArrayList<>();
    for (GameRecord record : tree) {
      if (record != null && passesContinentFilter(record)) {
        names.add(record.getName());
      }
    }
    return names;
  }

  private boolean passesContinentFilter(GameRecord record) {
    return continentFilter == null || record.getContinent() == continentFilter;
  }

  /**
   * Creates a lightweight boundary object used only to set iterator min/max by collectables.
   */
  private GameRecord createBoundaryRecord(int collectables) {
    GameRecord.Continent[] continents = GameRecord.Continent.values();
    GameRecord.Continent defaultContinent =
        continents.length == 0 ? null : continents[0];
    return new GameRecord("", defaultContinent, 0, 0, collectables, "000:00:00");
  }

  /**
   * Parses hhh:mm:ss into total seconds. Invalid formats are treated as very slow times.
   */
  private int parseCompletionTimeToSeconds(String completionTime) {
    if (completionTime == null) {
      return Integer.MAX_VALUE;
    }

    String[] parts = completionTime.trim().split(":");
    if (parts.length != 3) {
      return Integer.MAX_VALUE;
    }

    try {
      int hours = Integer.parseInt(parts[0]);
      int minutes = Integer.parseInt(parts[1]);
      int seconds = Integer.parseInt(parts[2]);
      return hours * 3600 + minutes * 60 + seconds;
    } catch (NumberFormatException e) {
      return Integer.MAX_VALUE;
    }
  }

  private int requiredIndex(Map<String, Integer> indexMap, String column) throws IOException {
    Integer idx = indexMap.get(column);
    if (idx == null) {
      throw new IOException("missing required column: " + column);
    }
    return idx;
  }

  private String getToken(String[] tokens, int index) {
    if (index < 0 || index >= tokens.length) {
      return "";
    }
    return tokens[index].trim();
  }

  private String[] splitCsvLine(String line) {
    return line.split(",", -1);
  }
}
