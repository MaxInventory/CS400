import java.util.Scanner;
import java.util.List;

public class Frontend implements FrontendInterface {
	
	private Scanner in;
	private BackendInterface backend;
	
	public Frontend(Scanner in, BackendInterface backend) {
		this.in = in;
		this.backend = backend;
	}
	
    /**
     * Displays instructions for the syntax of user commands.  And then
     * repeatedly gives the user an opportunity to issue new commands until
     * they enter "quit".  Uses the evaluateSingleCommand method below to
     * parse and run each command entered by the user.  If the backend ever
     * throws any exceptions, they should be caught here and reported to the
     * user.  The user should then continue to be able to issue subsequent
     * commands until they enter "quit".  This method must use the scanner
     * passed into the constructor to read commands input by the user.
     */
	@Override
	public void runCommandLoop() {
		String command = "";
		System.out.println("Enter commands or type 'quit' to exit");
		showCommandInstructions();
		command = in.nextLine().trim();
		
		while (!command.equals("quit")) {
			try {
				processSingleCommand(command);
			} catch (Exception e) {
				System.out.println("Error");
			}
			
			showCommandInstructions();			
			command = in.nextLine().trim();
		}
		
	}

    /**
     * Displays instructions for the user to understand the syntax of commands
     * that they are able to enter.  This should be displayed once from the
     * command loop, before the first user command is read in, and then later
     * in response to the user entering the command: help.
     *
     * The lowercase words in the following examples are keywords that the
     * user must match exactly in their commands, while the upper case words
     * are placeholders for arguments that the user can specify.  The following
     * are examples of valid command syntax that your frontend should be able
     * to handle correctly.
     *
     * submit NAME CONTINENT SCORE DAMAGE_TAKEN COLLECTABLES COMPLETION_TIME
     * submit multiple FILEPATH
     * collectables MAX
     * collectables MIN to MAX
     * location CONTINENT
     * show MAX_COUNT
     * show fastest times
     * help
     * quit
     */
	@Override
	public void showCommandInstructions() {
		System.out.println("Command Instructions:");
		System.out.println("submit NAME, CONTINENT, SCORE, DAMAGE_TAKEN, COLLECTABLES, COMPLETION_TIME");
		System.out.println("submit multiple FILEPATH");
		System.out.println("collectables MAX");
		System.out.println("collectables MIN to MAX");
		System.out.println("location CONTINENT");
		System.out.println("show MAX_COUNT");
		System.out.println("show fastest times");
		System.out.println("help");
		System.out.println("quit");

	}

	/**
     * This method takes a command entered by the user as input. It parses
     * that command to determine what kind of command it is, and then makes
     * use of the backend (which was passed to the constructor) to update the
     * state of that backend.  When a show or help command is issued, this
     * method prints the appropriate results to standard out.  When a command
     * does not follow the syntax rules described above, this method should
     * print out an error message that describes at least one defect in the
     * syntax of the provided command argument.
     *
     * Some notes on the expected behavior of the different commands:
     *     submit : results in backend adding a new record with the specific NAME, CONTINENT,
     *          SCORE, DAMAGE_TAKEN, COLLECTABLES, COMPLETION_TIME
     *          COMPLETION_TIME is of the format "hhh:mm:ss"
     *     submit multiple: results in backend loading data from specified path
     *     collectables: updates backend's range of records to return
     *                 should not result in any records being displayed
     *     location: updates backend's filter criteria
     *                   should not result in any records being displayed
     *     show: displays list of records with currently set thresholds and filters
     *           MAX_COUNT: argument limits the number of record names displayed
     *           to the first MAX_COUNT in the list returned from backend
     *           fastest times: argument displays results returned from the
     *           backend's getTopTen method
     *     help: displays command instructions
     *     quit: ends this program (handled by runCommandLoop method above)
     *           (do NOT use System.exit(), as this will interfere with tests)
     */
	@Override
	public void processSingleCommand(String command) {
		if (command == null || command.trim().isEmpty()) {
			System.out.println("Error: Command can't be empty");
			return;
		}
		
		String[] commands = command.trim().split("\\s+");
		String mainCom = commands[0].toLowerCase();
		try {
			switch (mainCom) {
			
				case "submit":
					// user submits multiple 
					if (commands.length >= 3 && commands[1].equals("multiple")) {
						String file = commands[2];
						backend.readData(file);
						System.out.println("Records from " + file);
						return;
					}
				
					// user submits record 
					if (commands.length != 7) {
						System.out.println("Error: Please submit NAME, CONTINENT, SCORE, DAMAGE_TAKEN, COLLECTABLES, COMPLETION_TIME");
						return;
					}
					
					String name = commands[1];
					GameRecord.Continent continent;
					try {
						continent = GameRecord.Continent.valueOf(commands[2].toUpperCase());
					} catch (IllegalArgumentException e) {
						System.out.println("Please submit valid continent");
						return;
					}
					
					int score;
					int damage;
					int collectables;
					try {
						score = Integer.parseInt(commands[3]);
						damage = Integer.parseInt(commands[4]);
						collectables = Integer.parseInt(commands[5]);
						
					} catch (IllegalArgumentException e) {
						System.out.println("Score, damage, and collectables should be integers");
						return;
					}
					
					String time = commands[6];
					String[] parts = time.split(":");
					if (parts.length != 3) { 
						System.out.println("Error: time must be formatted as hhh:mm:ss");
						return;
					}
					try {
						int hours = Integer.parseInt(parts[0]);
						int minutes = Integer.parseInt(parts[1]);
						int seconds = Integer.parseInt(parts[2]);
						
						if (minutes < 0 || minutes > 59 || seconds < 0 || seconds > 59) {
							System.out.println("Error: invalid time");
							return;
						}
					} catch (Exception e) {
						System.out.println("Error: time should be in integers");
						return;
					}
					
					GameRecord record = new GameRecord(name, continent, score, damage, collectables, time);
					backend.addRecord(record);
					break;
				case "collectables":
					if (commands.length != 3) {
						System.out.println("Error: include low and high values");
						return;
					}
					
					Integer low;
					if (commands[1].equalsIgnoreCase("null")) {
						low = null;
					} else {
						low = Integer.parseInt(commands[1]);
					}
					
					Integer high;
					if (commands[2].equalsIgnoreCase("null")) {
						high = null;
					} else {
						high = Integer.parseInt(commands[2]);
					}
					if(low > high) {
						System.out.println("Error: low can't be greater than high");
						return;
					}

					backend.getAndSetRange(low,  high);
					break;
					
				case "location":
					if (commands.length != 2) {
						System.out.println("Error: location must be printed or null");
						return;
					}
					
					GameRecord.Continent filter = null;
					if (!commands[1].equalsIgnoreCase("null")) {
						try {
							filter = GameRecord.Continent.valueOf(commands[1].toUpperCase());
						} catch (IllegalArgumentException e) {
							System.out.println("Error: location is invalid");
							return;
						}
					}
					backend.applyAndSetFilter(filter);
					break;
				case "show":
					// show fastest
					if (commands.length == 2 && commands[1].equalsIgnoreCase("fastest")) {
						List<String> fastest = backend.getTopTen();
						for (String fast : fastest) {
							System.out.println(fast);
						}
						return;
					}
					//show max count
					List<String> records = backend.getAndSetRange(null,  null);
					if (commands.length == 2) {
						int max;
						try {
							max = Integer.parseInt(commands[1]);
						} catch (Exception e) {
							System.out.println("Error: max count should be integer");
							return;
						}
						for (int i = 0; i < records.size() && i < max; i++) {
							System.out.println(records.get(i));
						}
					} else {
						for (String r : records) {
							System.out.println(r);
						}
					}
					break;
				case "help":
					showCommandInstructions();
					break;
					
				case "quit":
					break;
				default: 
					System.out.println("Error: this command is invalid");
			}
		} catch (Exception e) {
			System.out.println("Error: invalid command");
			
		}

	}
}
