import java.util.*;
import java.io.*;

/**
 * Backend class implements BackendInterface to manage Dungeion Driters data
 * on the leaderboard. Provides ability to read CSV data, filter, search by range
 * and retrieve the top ten records on completion time
 */
public class Backend implements BackendInterface {

	private IterableSortedCollection<GameRecord> records;
	private Integer currentLow;
	private Integer currentHigh;
	private GameRecord.Continent currentFilter;

	public Backend (IterableSortedCollection<GameRecord> records){
		this.records = records;
		this.currentLow = null;
		this.currentHigh = null;
		this.currentFilter = null;

	}

/**
 * Adds a record to the records storage variable records
 */
	@Override
	public void addRecord(GameRecord record){
		records.insert(record);
	}

/**
 * Loads game records from specified CSV file to the data structure
 * @param filename the path to the CSV file to be read
 * @throws IOException if the file cant be found or read
 */
	@Override
	public void readData(String filename) throws IOException{
		File fileNew = new File(filename);
		Scanner scnr = new Scanner(fileNew);

		if (scnr.hasNextLine()){
			scnr.nextLine();
		}
		while (scnr.hasNextLine()){
			String line = scnr.nextLine();
			String[] parts = line.split(",");
			String name = parts[0].trim();
			int collectibles = Integer.parseInt(parts[2].trim());
			GameRecord.Continent continent = GameRecord.Continent.valueOf(parts[1].trim().
										toUpperCase());
			String completionTime = (parts[5].trim());
			int additionalInt = Integer.parseInt(parts[3].trim());
			int  additionalIntTwo = Integer.parseInt(parts[4].trim());
			GameRecord record = new GameRecord(name, continent, collectibles, 
								additionalInt, additionalIntTwo, 
										completionTime);
			addRecord(record);
		}
	scnr.close();
	}

/**
 * REturns a list of game names whose collectibles fall in specific range
 * @param low the min. number of collectibles
 * @param high the max. number of collectibles
 * @return a list of player names matching the range criteria
 */
	@Override
	 public List<String> getAndSetRange(Integer low, Integer high) {
		this.currentLow = low;
		this.currentHigh = high;

		List<String> result = new ArrayList<>();

		for (GameRecord r : records){
			if (matchesCurrentSettings(r)) {
				result.add(r.getName());
			}
		}
		return result;
	}
	
	private boolean matchesCurrentSettings(GameRecord r){
		if (currentLow != null && r.getCollectables() < currentLow) return false;
		if (currentHigh != null && r.getCollectables() > currentHigh) return false;

		if (currentFilter != null && r.getContinent() != currentFilter) return false;
		return true;
	}

/**
 * Sets geographic filter and returns player names from the continent
 *  @param continent that Continent enum to filter by
 * @return a list of player names form the specified continet
 */
	@Override
	public List<String> applyAndSetFilter(GameRecord.Continent continent) {
		this.currentFilter = continent;
		List<String> result = new ArrayList<>();

		for (GameRecord r : records) {
			if (matchesCurrentSettings(r)) {
				result.add(r.getName());
			}
		}
		return result;
	}

/**
 * Retrieves the top 10 fastest completion times, applying filters
 * Completion times are compared ignoring formatting of colons
 * @return a list of the  top 10 player names
 */
	@Override
	public List<String> getTopTen() {
		List<GameRecord> matches = new ArrayList<>();
		for (GameRecord r : records){
			if (matchesCurrentSettings(r)) {
				matches.add(r);
			}
		}

		Collections.sort(matches, new Comparator<GameRecord>() {
		@Override
		public int compare(GameRecord a, GameRecord b) {
				return Double.compare(Double.parseDouble(a.getCompletionTime().
							replaceAll(":", "")),
							Double.parseDouble(b.getCompletionTime().
							replaceAll(":", "")));
			}
		});

		List<String> result = new ArrayList<>();
		for (int i = 0; i < matches.size() && i < 10; i++) {
			result.add(matches.get(i).getName());
		}
		return result;
	}
}

