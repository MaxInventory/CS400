import java.util.List;
import java.util.Scanner;
import java.io.IOException;

/**
 * Frontend implementation for CS400 Project 1 (Role: Frontend).
 * Implements the command loop and parses user commands to call the backend.
 *
 * Allowed imports: java.util and java.io only.
 */
public class Frontend implements FrontendInterface {

    private final Scanner in;
    private final BackendInterface backend;

    /**
     * Required constructor signature (per FrontendInterface comment).
     */
    public Frontend(Scanner in, BackendInterface backend) {
        if (in == null) throw new IllegalArgumentException("Scanner cannot be null");
        if (backend == null) throw new IllegalArgumentException("Backend cannot be null");
        this.in = in;
        this.backend = backend;
    }

    @Override
    public void runCommandLoop() {
        showCommandInstructions();
        while (true) {
            // simple prompt (safe for autograder)
            System.out.print("> ");

            String command;
            try {
                if (!in.hasNextLine()) break; // end-of-input
                command = in.nextLine();
            } catch (Exception e) {
                System.out.println("Error reading input. Try again.");
                continue;
            }

            if (command == null) continue;
            command = command.trim();
            if (command.equalsIgnoreCase("quit")) {
                break; // do NOT System.exit()
            }

            try {
                processSingleCommand(command);
            } catch (Exception e) {
                // Requirement: if backend throws exceptions, catch here and report,
                // then continue accepting commands until "quit".
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    @Override
    public void showCommandInstructions() {
        System.out.println("Commands:");
        System.out.println("  submit NAME CONTINENT SCORE DAMAGE_TAKEN COLLECTABLES COMPLETION_TIME");
        System.out.println("    - COMPLETION_TIME format: hhh:mm:ss");
        System.out.println("  submit multiple FILEPATH");
        System.out.println("  collectables MAX");
        System.out.println("  collectables MIN to MAX");
        System.out.println("  location CONTINENT");
        System.out.println("  show MAX_COUNT");
        System.out.println("  show fastest times");
        System.out.println("  help");
        System.out.println("  quit");
    }

    @Override
    public void processSingleCommand(String command) {
        if (command == null) {
            System.out.println("Invalid command: empty input.");
            return;
        }
        String trimmed = command.trim();
        if (trimmed.isEmpty()) {
            System.out.println("Invalid command: empty input.");
            return;
        }

        // Special-case help (no backend)
        if (trimmed.equalsIgnoreCase("help")) {
            showCommandInstructions();
            return;
        }

        // Tokenize by whitespace (simple, matches spec examples)
        String[] parts = trimmed.split("\\s+");
        String keyword = parts[0].toLowerCase();

        switch (keyword) {
            case "submit":
                handleSubmit(trimmed, parts);
                return;

            case "collectables":
                handleCollectables(parts);
                return;

            case "location":
                handleLocation(parts);
                return;

            case "show":
                handleShow(parts);
                return;

            default:
                System.out.println("Invalid command: unknown command '" + parts[0] + "'. Type 'help' for options.");
        }
    }


    private void handleSubmit(String full, String[] parts) {
        // submit multiple FILEPATH
        if (parts.length >= 2 && parts[1].equalsIgnoreCase("multiple")) {
            if (parts.length < 3) {
                System.out.println("Invalid submit syntax: missing FILEPATH.");
                return;
            }
            // Take the filepath as the remainder of the command after "submit multiple "
            String prefix = "submit multiple";
            int idx = indexOfIgnoreCase(full, prefix);
            String filepath = (idx >= 0) ? full.substring(idx + prefix.length()).trim() : parts[2];

            if (filepath.isEmpty()) {
                System.out.println("Invalid submit syntax: missing FILEPATH.");
                return;
            }
            try {
                backend.readData(filepath);
                System.out.println("Loaded records from: " + filepath);
            } catch (IOException e) {
                // let runCommandLoop catch? The spec says backend exceptions caught there.
                // But it's fine to report here too.
                throw new RuntimeException("Could not read data from '" + filepath + "': " + e.getMessage());
            }
            return;
        }

        // submit NAME CONTINENT SCORE DAMAGE_TAKEN COLLECTABLES COMPLETION_TIME
        if (parts.length != 7) {
            System.out.println("Invalid submit syntax: expected 6 arguments.");
            System.out.println("Example: submit NAME CONTINENT SCORE DAMAGE_TAKEN COLLECTABLES COMPLETION_TIME");
            return;
        }

        String name = parts[1];
        GameRecord.Continent continent;
        try {
            continent = parseContinent(parts[2]);
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid submit syntax: unknown continent '" + parts[2] + "'.");
            return;
        }

        Integer score = parseIntOrReport("SCORE", parts[3]);
        if (score == null) return;

        Integer damageTaken = parseIntOrReport("DAMAGE_TAKEN", parts[4]);
        if (damageTaken == null) return;

        Integer collectables = parseIntOrReport("COLLECTABLES", parts[5]);
        if (collectables == null) return;

        String time = parts[6];
        if (!isValidTimeFormat(time)) {
            System.out.println("Invalid submit syntax: COMPLETION_TIME must be in format hhh:mm:ss (e.g., 034:38:52).");
            return;
        }

        GameRecord record = new GameRecord(name, continent, score, damageTaken, collectables, time);
        backend.addRecord(record);
        System.out.println("Submitted record for: " + name);
    }

    private void handleCollectables(String[] parts) {
        // collectables MAX
        // collectables MIN to MAX
        if (parts.length == 2) {
            Integer max = parseIntOrReport("MAX", parts[1]);
            if (max == null) return;

            backend.getAndSetRange(null, max);
            System.out.println("Collectables range set: <= " + max);
            return;
        }

        if (parts.length == 4 && parts[2].equalsIgnoreCase("to")) {
            Integer min = parseIntOrReport("MIN", parts[1]);
            if (min == null) return;
            Integer max = parseIntOrReport("MAX", parts[3]);
            if (max == null) return;

            if (min > max) {
                System.out.println("Invalid collectables syntax: MIN cannot be greater than MAX.");
                return;
            }

            backend.getAndSetRange(min, max);
            System.out.println("Collectables range set: " + min + " to " + max);
            return;
        }

        System.out.println("Invalid collectables syntax.");
        System.out.println("Examples: collectables 150   OR   collectables 10 to 200");
    }

    private void handleLocation(String[] parts) {
        // location CONTINENT
        if (parts.length != 2) {
            System.out.println("Invalid location syntax: expected CONTINENT.");
            System.out.println("Example: location AFRICA");
            return;
        }

        GameRecord.Continent continent;
        try {
            continent = parseContinent(parts[1]);
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid location syntax: unknown continent '" + parts[1] + "'.");
            return;
        }

        backend.applyAndSetFilter(continent);
        System.out.println("Location filter set: " + continent);
    }

    private void handleShow(String[] parts) {
        // show MAX_COUNT
        // show fastest times
        if (parts.length == 3 && parts[1].equalsIgnoreCase("fastest") && parts[2].equalsIgnoreCase("times")) {
            List<String> names = backend.getTopTen();
            printNames(names, names.size());
            return;
        }

        if (parts.length == 2) {
            Integer maxCount = parseIntOrReport("MAX_COUNT", parts[1]);
            if (maxCount == null) return;
            if (maxCount < 0) {
                System.out.println("Invalid show syntax: MAX_COUNT must be non-negative.");
                return;
            }

            List<String> names = backend.getTopTen();
            printNames(names, maxCount);
            return;
        }

        System.out.println("Invalid show syntax.");
        System.out.println("Examples: show 5   OR   show fastest times");
    }


    private void printNames(List<String> names, int maxCount) {
        if (names == null || names.isEmpty()) {
            System.out.println("(no records)");
            return;
        }
        int limit = Math.min(maxCount, names.size());
        for (int i = 0; i < limit; i++) {
            System.out.println((i + 1) + ". " + names.get(i));
        }
    }

    private Integer parseIntOrReport(String label, String token) {
        try {
            return Integer.valueOf(token);
        } catch (NumberFormatException e) {
            System.out.println("Invalid number for " + label + ": '" + token + "'.");
            return null;
        }
    }

    private GameRecord.Continent parseContinent(String token) {
        // Allow case-insensitive matching for user friendliness
        return GameRecord.Continent.valueOf(token.trim().toUpperCase());
    }

    private boolean isValidTimeFormat(String t) {
        // Expect hhh:mm:ss where hhh is 1+ digits, mm and ss are 2 digits (but we allow 1-2 to be lenient)
        if (t == null) return false;
        String[] seg = t.split(":");
        if (seg.length != 3) return false;
        return isDigits(seg[0]) && isDigits(seg[1]) && isDigits(seg[2]);
    }

    private boolean isDigits(String s) {
        if (s == null || s.isEmpty()) return false;
        for (int i = 0; i < s.length(); i++) {
            if (!Character.isDigit(s.charAt(i))) return false;
        }
        return true;
    }

    private int indexOfIgnoreCase(String haystack, String needle) {
        // Small helper to find "submit multiple" regardless of case
        String h = haystack.toLowerCase();
        String n = needle.toLowerCase();
        return h.indexOf(n);
    }
}
