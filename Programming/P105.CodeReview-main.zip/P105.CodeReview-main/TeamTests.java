import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.Scanner;

/**
 * This class is for testing teammates' Frontend codes.
 */
public class TeamTests {

    /**
     * This is a helper method to create a FrontendInterface instance 
     * using the placeholder backend.
     * It helps in testing teammates' different implementations.
     * 
     * @return frontend for testing
     */
    private FrontendInterface createFrontend() {
        //Using Tree_Placeholder() and Backend_Placeholder to create a backend object
        IterableSortedCollection<GameRecord> tree = new Tree_Placeholder();
        BackendInterface backend = new Backend_Placeholder(tree);
        //returns a frontend instance
        return new Frontend(new Scanner(System.in), backend);
    }

    /**
     * Tests that the program outputs command guidance 
     * when the user types "help".
     *
     * Pass if the output conatins "help", "command", "instruction"
     */
    @Test
    public void testHelp() {
    	//input "help" and "quit"
        TextUITester tester = new TextUITester("help\nquit\n");
        FrontendInterface frontend = createFrontend();
        //runs runCommandLoop()
        frontend.runCommandLoop();
        //contains the output and checks it
        String output = tester.checkOutput().toLowerCase();
        assertTrue(output.contains("help") || output.contains("command") || output.contains("instruction"));
    }

    /**
     * Tests that if an invalid input results in an error message.
     *
     * Pass if the output contains "error" and "invalid"
     */
    @Test
    public void testInvalid() {
        //input "invalid" and "quit"
        TextUITester tester = new TextUITester("boewjne\nquit\n");
        FrontendInterface frontend = createFrontend();
        //runs runCommandLoop()
        frontend.runCommandLoop();
        //contains the output and checks it
        String out = tester.checkOutput().toLowerCase();
        assertTrue(out.contains("error") || out.contains("invalid"));
    }

    /**
     * Tests that "quit" exits the command loop and not hanging.
     *
     * Pass if the output exists
     */
    @Test
    public void testQuit() {
        //input "quit"
        TextUITester tester = new TextUITester("quit\n");
        FrontendInterface frontend = createFrontend();
        //runs runCommandLoop()
        frontend.runCommandLoop();
        //check if the output exists
        assertNotNull(tester.checkOutput());
    }
}
