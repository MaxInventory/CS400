import java.util.List;
import java.util.Scanner;

public class Frontend implements FrontendInterface {

    private Scanner in;
    private BackendInterface backend;

    public Frontend(Scanner in, BackendInterface backend) {
	this.in = in;
	this.backend = backend;
    }

    public void runCommandLoop() {
	System.out.println("Here is how the syntax for commands should be");
	showCommandInstructions();
	System.out.println();

	while (true) {
	    System.out.print("Enter a command: ");
	    String command = in.nextLine();
	    if (command.equals("quit"))
		break;
	    processSingleCommand(command);
	}
    }

    public void showCommandInstructions() {
	System.out.println("submit NAME CONTINENT SCORE DAMAGE_TAKEN COLLECTABLES COMPLETION_TIME");
	System.out.println("submit multiple FILEPATH");
	System.out.println("collectables MAX");
	System.out.println("collectables MIN to MAX");
	System.out.println("location CONTINENT");
	System.out.println("show MAX_COUNT");
	System.out.println("show fastest times");
	System.out.println("help");
	System.out.println("quit");
    }

    public void processSingleCommand(String command) {
	if (command == null || command.trim().length() == 0) {
	    System.out.println("Empty command");
	    return;
	}

	String[] words = command.trim().split("\\s+");

	if (words[0].equals("submit"))
	    processSubmit(words);
	else if (words[0].equals("collectables"))
	    processCollectables(words);
	else if (words[0].equals("show"))
	    processShow(words);
	else if (words[0].equals("help"))
	    showCommandInstructions();
	else if (words[0].equals("location")) {
	    if (words.length != 2)
		System.out.println("Error: need to input continent");
	    else
		backend.applyAndSetFilter(GameRecord.Continent.valueOf(words[1]));
	} else
	    System.out.println("Unknown command");

    }

    private void processSubmit(String[] words) {
	if (words[1].equals("multiple") && words.length == 3) {
	    try {
	        backend.readData(words[2]);
	    } catch (Exception e) {
		System.out.println("Exception when giving file");
	    }
	    return;
	}

	if (words.length == 7) {
	    String name = words[1];
	    GameRecord.Continent continent = GameRecord.Continent.valueOf(words[2]); 
	    int score = Integer.parseInt(words[3]);
	    int damage = Integer.parseInt(words[4]);
	    int collectables = Integer.parseInt(words[5]);
	    String time = words[6];

	    backend.addRecord(new GameRecord(name, continent, score, damage, collectables, time)); 
	    return;
	}

	System.out.println("Incorrect syntax for submit command");

    }

    private void processCollectables(String[] words) {
	if (words.length == 2) {
	    Integer high = Integer.parseInt(words[1]);
	    backend.getAndSetRange(null, high);
	    return;
	}

	if (words.length == 4 && words[2].equals("to")) {
	    Integer low = Integer.parseInt(words[1]);
	    Integer high = Integer.parseInt(words[3]);
	    backend.getAndSetRange(low, high);
	    return;
	}

	System.out.println("Incorrect syntax for collectables command");
    }

    private void processShow(String[] words) {
	if (words.length == 2) {
	    int max = Integer.parseInt(words[1]);
	    List<String> display = backend.getAndSetRange(null, null);
	    for (int i = 0; i < max && i < display.size(); i++)
		System.out.println(display.get(i));
	    return;
	}

	if (words.length == 3 && words[1].equals("fastest") && words[2].equals("times")) {
	    for (String s : backend.getTopTen())
		System.out.println(s);
	    return;
	}

	System.out.println("Incorrect syntax for show command");
    }

}
