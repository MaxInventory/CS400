/*
 * Author: Jihun Chung 
 * Email: chung92@wisc.edu
 * Course: CS 400, Spring 2026
 * Assignment: P106.Iterator
 */

/**
 * This class represents BST rotation.
 * It extends BinarySearchTree and implements a rotate method.
 * Includes test methods, and a helper method to make testing easier
 * 
 * @param <T> the type of data that is going to be stored
 */
public class BSTRotation<T extends Comparable<T>> extends BinarySearchTree<T> {
	
	//data fields (BinaryNode<T> root from BinarySearchTree.java)
	
	//default constructor
	public BSTRotation() {
		super();
	}
	
	/**
     * Performs the rotation operation on the provided nodes within this tree.
     * When the provided child is a left child of the provided parent, this
     * method will perform a right rotation. When the provided child is a right
     * child of the provided parent, this method will perform a left rotation.
     *
     * @param child is the node being rotated from child to parent position 
     * @param parent is the node being rotated from parent to child position
     * @throws NullPointerException if any of the parameter is null
     * @throws IllegalArgumentException if the child is not actually the child of the parent
     * 
     */
    protected void rotate(BinaryNode<T> child, BinaryNode<T> parent) {
        if (child == null || parent == null) {
        	throw new NullPointerException("Either the child or the parent is null");
        }
        if (child.getUp() != parent || (parent.getLeft() != child && parent.getRight() != child)) {
        	throw new IllegalArgumentException("child used is not actual child of the parent");
        }
        //parent's parent
        BinaryNode<T> parentUp = parent.getUp();
        
        //if the child is parent's left child
        if (parent.getLeft() == child) {
        	//move child's right subtree -> parent's left subtree
        	BinaryNode<T> childRight = child.getRight();
        	parent.setLeft(childRight);
        	if (childRight != null) {
        		childRight.setUp(parent);
        	}
        	//flip the relationship
        	child.setRight(parent);
        	parent.setUp(child);
        	//connect the rotated subtree to the root
        	child.setUp(parentUp);
        	if (parentUp == null) {
        		this.root = child;
        	} else if (parentUp.getLeft() == parent) {
        		parentUp.setLeft(child);
        	} else if (parentUp.getRight() == parent) {
        		parentUp.setRight(child);
        	} else {
        		throw new IllegalStateException("parentUp is not actual parent's parent");
        	}
        //if the child is parent's right child
        } else if (parent.getRight() == child) {
        	//move child's left subtree -> parent's right subtree
        	BinaryNode<T> childLeft = child.getLeft();
        	parent.setRight(childLeft);
        	if (childLeft != null) {
        		childLeft.setUp(parent);
        	}
        	//flip the relationship
        	child.setLeft(parent);
        	parent.setUp(child);
        	//connect the rotated subtree to the root
        	child.setUp(parentUp);
        	if (parentUp == null) {
        		this.root = child;
        	} else if (parentUp.getLeft() == parent) {
        		parentUp.setLeft(child);
        	} else if (parentUp.getRight() == parent) {
        		parentUp.setRight(child);
        	} else {
        		throw new IllegalStateException("parentUp is not actual parent's parent");
        	}
        //if the child is not the parent's child
        } else {
        	throw new IllegalArgumentException("child used is not actual child of the parent");
        } 
    }
    
    /**
     * Helper method to check the node relationship
     * 
     * @param child the child node to check the connection
     * @param <Y> the type of the BinaryNode
     * @return true if the connection is correct
     */
    private <Y> boolean checkConnection (BinaryNode<Y> child) {
    	if (child == null) {
    		return true;
    	}
    	if (child.getLeft() != null && child.getLeft().getUp() != child) {
    		return false;
    	}
    	if (child.getRight() != null && child.getRight().getUp() != child) {
    		return false;
    	}
    	return true;
    }

}
