/*
 * Author: Jihun Chung
 * Email: chung92@wisc.edu
 * Course: CS 400, Spring 2026
 * Assignment: P106.Iterator
 */

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Iterator;
import java.util.Stack;
import java.util.NoSuchElementException;

/**
 * This class extends RedBlackTree into a tree that supports iterating over the values it
 * stores in sorted, ascending order.
 */
public class RBTreeIterable<T extends Comparable<T>>
        extends RedBlackTree<T> implements IterableSortedCollection<T> {

    //Data Fields
    private Comparable<T> min = null;
    private Comparable<T> max = null;


    /**
     * Allows setting the start (minimum) value of the iterator. When this method is called,
     * every iterator created after it will use the minimum set by this method until this method
     * is called again to set a new minimum value.
     *
     * @param min the minimum for iterators created for this tree, or null for no minimum
     */
    public void setIteratorMin(Comparable<T> min) {
	this.min = min;
    }

    /**
     * Allows setting the stop (maximum) value of the iterator. When this method is called,
     * every iterator created after it will use the maximum set by this method until this method
     * is called again to set a new maximum value.
     *
     * @param max the maximum for iterators created for this tree, or null for no maximum
     */
    public void setIteratorMax(Comparable<T> max) {
	this.max = max;
    }

    /**
     * Returns an iterator over the values stored in this tree. The iterator uses the
     * start (minimum) value set by a previous call to setIteratorMin, and the stop (maximum)
     * value set by a previous call to setIteratorMax. If setIteratorMin has not been called
     * before, or if it was called with a null argument, the iterator uses no minimum value
     * and starts with the lowest value that exists in the tree. If setIteratorMax has not been
     * called before, or if it was called with a null argument, the iterator uses no maximum
     * value and finishes with the highest value that exists in the tree.
     */
    public Iterator<T> iterator() {
        return new TreeIterator<T>(this.root, this.min, this.max);
    }

    /**
     * Nested class for Iterator objects created for this tree and returned by the iterator method.
     * This iterator follows an in-order traversal of the tree and returns the values in sorted,
     * ascending order.
     */
    protected static class TreeIterator<R extends Comparable<R>> implements Iterator<R> {

        // stores the start point (minimum) for the iterator
        Comparable<R> min = null;
        // stores the stop point (maximum) for the iterator
        Comparable<R> max = null;
        // stores the stack that keeps track of the inorder traversal
        Stack<BinaryNode<R>> stack = null;

        /**
         * Constructor for a new iterator if the tree with root as its root node, and
         * min as the start (minimum) value (or null if no start value) and max as the
         * stop (maximum) value (or null if no stop value) of the new iterator.
         * Time complexity should be O(log n).
         *
         * @param root root node of the tree to traverse
         * @param min  the minimum value that the iterator will return
         * @param max  the maximum value that the iterator will return
         */
        public TreeIterator(BinaryNode<R> root, Comparable<R> min, Comparable<R> max) {
	this.min = min;
	this.max = max;
	this.stack = new Stack<>();
	updateStack(root);
        }

        /**
         * Helper method for initializing and updating the stack. This method both
         * - finds the next data value stored in the tree (or subtree) that is between
         * start(minimum) and stop(maximum) point (including start and stop points
         * themselves), and
         * - builds up the stack of ancestor nodes that contain values between
         * start(minimum) and stop(maximum) values (including start and stop values
         * themselves) so that those nodes can be visited in the future.
         *
         * @param node the root node of the subtree to process
         */
        private void updateStack(BinaryNode<R> node) {
		if (node == null) {
			return;
		}
		R data = node.getData();
		if (min != null && min.compareTo(data) > 0) {
			updateStack(node.getRight());
		} else if (max != null && max.compareTo(data) < 0) {
			updateStack(node.getLeft());
		} else {
			stack.push(node);
			updateStack(node.getLeft());
		}
        }

        /**
         * Returns true if the iterator has another value to return, and false otherwise.
         */
        public boolean hasNext() {
        	if (stack == null || stack.isEmpty()) {
			return false;
		}
		if (max == null) {
			return true;
		}
		return max.compareTo(stack.peek().getData()) >= 0;
        }

        /**
         * Returns the next value of the iterator.
         * Amortized time complexity should be O(1).
         * Worst case time complexity should be O(log n).
         * Do not implement this method by linearly walking through the
         * entire tree from the smallest element until the start bound is reached.
         * That process should occur only once during construction of the
         * iterator object.
         *
         * @throws NoSuchElementException if the iterator has no more values to return
         */
        public R next() {
		if (!hasNext()) {
			throw new NoSuchElementException();
		}
		BinaryNode<R> current = stack.pop();
		R next = current.getData();
		if (max == null || max.compareTo(next) >= 0) {
			updateStack(current.getRight());
		}
            return next;
        }
    }
	/////////////////////////////JUnit Tests//////////////////////////////////////////////
	/**
	*  testIntegerDuplicate
	*
	*  This tests an Integer tree with duplicates.
	*  Pass if duplicates are not skipped. Else, Fail.
	*/
	@Test
	public void testIntegerDuplicate() {
		//create an Integer tree
		RBTreeIterable<Integer> tree = new RBTreeIterable<>();
		tree.insert(10);
		tree.insert(9);
		tree.insert(5);
		tree.insert(8);
		tree.insert(5);	//duplicate
		tree.insert(9); //duplicate

		//set the min and max
		tree.setIteratorMin(null);
		tree.setIteratorMax(null);

		Iterator<Integer> iter = tree.iterator();

		//create a tree to check
		Stack<Integer> check = new Stack<>();
		check.push(10);
		check.push(9);
		check.push(9);
		check.push(8);
		check.push(5);
		check.push(5);

		//check if it the tree is formed as it have to
		while (iter.hasNext()) {
			assertFalse(check.isEmpty());
			assertEquals(check.pop(), iter.next());
		}
		assertTrue(check.isEmpty());
		assertFalse(iter.hasNext());
		//check for the exception
		assertThrows(NoSuchElementException.class, () -> iter.next());
	}

	/**
	*  testStringMinBound
	*
	*  This tests a String tree and a min bound only.
	*  Pass if the min bound applies. Else, Fail
	*/
	@Test
	public void testStringMinBound() {
		//create a String tree
		RBTreeIterable<String> tree = new RBTreeIterable<>();
		tree.insert("a");
		tree.insert("b");
		tree.insert("c");
		tree.insert("d");
		tree.insert("e");

		//set only min
		tree.setIteratorMin("b");
		tree.setIteratorMax(null);

		Iterator<String> iter = tree.iterator();

		//create a tree to check (filtered by min)
		Stack<String> check = new Stack<>();
		check.push("e");
		check.push("d");
		check.push("c");
		check.push("b");

		//check if the tree have been created as it have to
		while (iter.hasNext()) {
			assertFalse(check.isEmpty());
			assertEquals(check.pop(), iter.next());
		}
		assertTrue(check.isEmpty());
		assertFalse(iter.hasNext());
	}

	/**
	*  testIntegerMinAndMax
	*
	*  This tests a tree with min and max bound setting.
	*  Pass, if the bound is applied properly, and duplicates are not skipped.
	*  Else, Fail.
	*/
	@Test
	public void testIntegerMinAndMax() {
		//create an Integer tree
		RBTreeIterable<Integer> tree = new RBTreeIterable<>();
		tree.insert(10);
		tree.insert(9);
		tree.insert(7);
		tree.insert(8);
		tree.insert(5);
		tree.insert(9); //duplicate
		tree.insert(7); //duplicate
		tree.insert(3);

		//set the min and max
		tree.setIteratorMin(4);
		tree.setIteratorMax(8);

		Iterator<Integer> iter = tree.iterator();

		//create a tree to check
		Stack<Integer> check = new Stack<>();
		check.push(8);
		check.push(7);
		check.push(7);
		check.push(5);

		//check if it the tree is formed as it have to
		while (iter.hasNext()) {
			assertFalse(check.isEmpty());
			int next = iter.next();
			assertTrue(next >= 4 && next <= 8);
			assertEquals(check.pop(), next);
		}
		assertTrue(check.isEmpty());
		assertFalse(iter.hasNext());
		//check for the exception
		assertThrows(NoSuchElementException.class, () -> iter.next());
	}
}
