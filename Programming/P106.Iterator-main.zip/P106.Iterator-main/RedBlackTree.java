/*
 * Author: Jihun Chung 
 * Email: chung92@wisc.edu
 * Course: CS 400, Spring 2026
 * Assignment: P106. Iterator
 * 
 */

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/**
 * Red-Black Tree implementation for insertion only.
 *
 * @param <T> the type of data stored in the tree
 */
public class RedBlackTree<T extends Comparable<T>> extends BSTRotation<T> {

    // Default Constructor
    public RedBlackTree() {
        super();
    }

    /**
     * Inserts a new data value into the RedBlackTree as a RED node (except root),
     * then repairs any red property violations and enforces a BLACK root.
     *
     * @param data the new value being inserted
     * @throws NullPointerException if data is null
     */
    @Override
    public void insert(T data) throws NullPointerException {
        if (data == null) {
            throw new NullPointerException("data argument is null");
        }
        RedBlackNode<T> newNode = new RedBlackNode<>(data);
        newNode.isBlackNode = false;
        if (root == null) {
            this.root = newNode;
            this.root.setUp(null);
            ((RedBlackNode<T>) root).isBlackNode = true; 
            return;
        }
        insertHelper(newNode);
        ensureRedProperty(newNode);
        ((RedBlackNode<T>) root).isBlackNode = true;
    }

    /**
     * Checks if a new red node in the RedBlackTree causes a red property violation
     * by having a red parent. If this is not the case, the method terminates without
     * making any changes to the tree. If a red property violation is detected, then
     * the method repairs this violation and any additional red property violations
     * that are generated as a result of the applied repair operation.
     * Using this method might cause nodes with a value equal to the value of one of
     * their ancestors to appear within the left and the right subtree of that ancestor,
     * even if the original insertion procedure consistently inserts such nodes into only
     * the left or the right subtree. But it will preserve the ordering of nodes within
     * the tree.
     * @param newNode a newly inserted red node, or a node turned red by previous repair
     */
    protected void ensureRedProperty(RedBlackNode<T> newNode) {
        if (newNode == null) {
        	return;
        }
        RedBlackNode<T> parent = parent(newNode);
	if (parent == null) {
		return;
	}
	if (!isRed(parent)) {
		return;
	}
	RedBlackNode<T> grand = parent(parent);
	if (grand == null) {
		return;
	}
	RedBlackNode<T> uncle;
       	// if parent is grandparent's Left Child
        if (parent == leftChild(grand)) {
                uncle = rightChild(grand);
	} else {
		uncle = leftChild(grand);
	}
        // if uncle is Red, recolor and switch grandparent with newNode
        if (isRed(uncle)) {
        parent.isBlackNode = true;
        uncle.isBlackNode = true;
        grand.isBlackNode = false;
        ensureRedProperty(grand);
        return;
	}

        // if uncle is Black, and left child of grand
        if (parent == leftChild(grand)) {
	// If newNode is Right Child, left rotate
                if (newNode == rightChild(parent)) {
                    rotate(newNode, parent);
                    parent = newNode;
                }

                //right rotation
                rotate(parent, grand);
                parent.isBlackNode = true;
                grand.isBlackNode = false;
            } else { 
            	//if newNode is parent's Left Child
                if (newNode == leftChild(parent)) {
			rotate(newNode, parent);
			parent = newNode;
		}
		rotate(parent, grand);
                parent.isBlackNode = true;
                grand.isBlackNode = false;
                }
    }

    /**
     * Helper Method to check if it is a red node
     * 
     * @param node that have to be checked if it is red node
     * @return true if it is a red node
     */
    private boolean isRed(RedBlackNode<T> node) {
        return node != null && !node.isBlackNode;
    }

    /**
     * Help Method to find its parent
     * 
     * @param node that you want to find its parent
     * @return the parent node
     */
    private RedBlackNode<T> parent(RedBlackNode<T> node) {
        if (node == null) {
        	return null;
        }
        return node.getUp();
    }

    /**
     * Helper Method to find its left child
     * 
     * @param node that you want to find its left child
     * @return the left child
     */
    private RedBlackNode<T> leftChild(RedBlackNode<T> node) {
        if (node == null) {
        	return null;
        }
        return node.getLeft();
    }

    /**
     * Helper Method to find its right child
     * 
     * @param node that you want to find its right child
     * @return the right child
     */
    private RedBlackNode<T> rightChild(RedBlackNode<T> node) {
        if (node == null) {
        	return null;
        }
        return node.getRight();
    }
}
