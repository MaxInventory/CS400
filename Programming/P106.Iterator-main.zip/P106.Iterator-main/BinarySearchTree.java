/*
 * Author: Jihun Chung 
 * Email: chung92@wisc.edu
 * Course: CS 400, Spring 2026
 * Assignment: P106.Iterator
 * 
 */

import java.util.Stack;

/**
 * This class represents Binary Search Tree.
 * The values will be stored in sorted order.
 * This class implements the SortedCollection Interface and use BinaryNodes.
 * It includes BST methods, a helper method, and test methods.
 * 
 * @param <T> the type of data that will be stored in the tree
 */

public class BinarySearchTree<T extends Comparable<T>> implements SortedCollection<T> {
	
	//Data Field
	protected BinaryNode<T> root;
	
	//Default Constructor
	public BinarySearchTree() {
		root = null;
	}
	
	/**
     * Performs the naive binary search tree insert algorithm to recursively
     * insert the provided newNode (which has already been initialized with a
     * data value) into the provided tree/subtree. When the provided subtree
     * is null, this method does nothing. 
     */
    protected void insertHelper(BinaryNode<T> newNode, BinaryNode<T> subtree) {
        if (subtree == null) {
        	return;
        }
        int where = newNode.getData().compareTo(subtree.getData());
        if (where <= 0) {
        	if (subtree.getLeft() == null) {
        		subtree.setLeft(newNode);
        		newNode.setUp(subtree);
        	} else {
        		insertHelper(newNode, subtree.getLeft());
        	}
        } else {
        	if (subtree.getRight() == null) {
        		subtree.setRight(newNode);
        		newNode.setUp(subtree);
        	} else {
        		insertHelper(newNode, subtree.getRight());
        	}
        }
    }
	
	/**
 	* Inserts newNode into this tree starting from the root.
 	*/
	protected void insertHelper(BinaryNode<T> newNode) {
    	if (newNode == null) {
			return;
		}
    	if (root == null) {
        	root = newNode;
        	newNode.setUp(null);
        	return;
    	}
    	insertHelper(newNode, root);
	}

    /**
     * Inserts a new data value into the sorted collection.
     * 
     * @param data the new value being inserted
     * @throws NullPointerException if data argument is null, we do not allow
     * null values to be stored within a SortedCollection
     */
	@Override
	public void insert(T data) throws NullPointerException {
		if (data == null) {
			throw new NullPointerException("data argument is null");
		}
		BinaryNode<T> newNode = new BinaryNode<>(data);
		if (root == null) {
			root = newNode;
			root.setUp(null);
			return;
		}
		insertHelper(newNode, root);
	}

	/**
     * Check whether data is stored in the tree.
     * 
     * @param find the value to check for in the collection
     * @return true if the collection contains data one or more times, 
     * and false otherwise
     */
	@Override
	public boolean contains(Comparable<T> find) {
		if (find == null) {
			throw new NullPointerException("find argument is null");
		}
		BinaryNode<T> check = root;
		while (check != null) {
			int where = find.compareTo(check.getData());
			if (where == 0) {
				return true;
			} else if (where < 0) {
				check = check.getLeft();
			} else {
				check = check.getRight();
			}
		}
		return false;
	}

	/**
     * Counts the number of values in the collection, with each duplicate value
     * being counted separately within the value returned.
     * 
     * @return the number of values in the collection, including duplicates
     */
	@Override
	public int size() {
		int counts = 0;
		Stack<BinaryNode<T>> stack = new Stack<>();
		if (root != null) {
			stack.push(root);
		}
		while (!stack.isEmpty()) {
			BinaryNode<T> node = stack.pop();
			counts++;
			if (node.getLeft() != null) {
				stack.push(node.getLeft());
			}
			if (node.getRight() != null) {
				stack.push(node.getRight());
			}
		}
		return counts;
	}

	/**
     * Checks if the collection is empty.
     * @return true if the collection contains 0 values, false otherwise
     */
	@Override
	public boolean isEmpty() {
		if (root == null) {
			return true;
		} else {
			return false;
		}
	}

	/**
     * Removes all values and duplicates from the collection.
     */
	@Override
	public void clear() {
		root = null;
	}

}
