import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.util.List;
import java.io.IOException;
import java.util.Map;
import java.util.HashMap;

/**
 * BackendInterface - CS400 Project 1: Game Records Leaderboard
 */
public class Backend implements BackendInterface {
    
    //Data Field
    private IterableSortedCollection<GameRecord> tree;
    private GameRecord.Continent filter = null;

    //public Backend(IterableSortedCollection<GameRecord> tree)
    // Your constructor must have the signature above. All methods below must
    // use the provided tree to store, sort, and iterate through records. This
    // will enable you to create some tests that use the placeholder tree, and
    // others that make use of a working tree, depending on what is passed
    // into this constructor.
    public Backend(IterableSortedCollection<GameRecord> tree){
	if (tree == null) {
	   throw new IllegalArgumentException("tree is null");
	}
	this.tree = tree;
    }
    /** Add and stores the specified record to the tree. Don't forget that the GameRecord
     *  must have the Comparator set. This will be used to store these records in order within your
     *  tree, and to retrieve them by collectables range in the getRange method.
     * @param record the game record to add
     */
    @Override
    public void addRecord(GameRecord record) {
	if (record == null) {
	   throw new IllegalArgumentException("record is null");
	}
	tree.insert(record);
    }
  
    /**
     * Loads data from the .csv file referenced by filename.  You can rely
     * on the exact headers found in the provided records.csv, but you should
     * not rely on them always being presented in this order or on there
     * not being additional columns describing other record qualities.
     * After reading records from the file, the records are inserted into
     * the tree passed to this backend's constructor. This will be used to store these records in order within your
     * tree, and to retrieve them by score range in the getRange method.
     * @param filename is the name of the csv file to load data from
     * @throws IOException when there is trouble finding/reading file
     */
    @Override
    public void readData(String filename) throws IOException {
	if (filename == null || filename.isBlank()) {
	   throw new IllegalArgumentException("filename is null");
	}
	try (Scanner sc = new Scanner(new File(filename))) {
	    //if exmpty, end
	    if (!sc.hasNextLine()) {
		return;
	    }
		//splits it
		String[] headers = sc.nextLine().split(",", -1);
		//put it in a map after trim and converting to LowerCase
		Map<String, Integer> clHeaders = new HashMap<>();
		for (int i = 0; i < headers.length; i++) {
		    clHeaders.put(headers[i].trim().toLowerCase(), i);
		}
		//store index of each terms
		int name = mustHave(clHeaders, "name");
		int continent = mustHave(clHeaders, "continent");
		int score = mustHave(clHeaders, "score");
		int maxHealth = mustHaveTwo(clHeaders, "max_health", "damage_taken");
		int collectables = mustHave(clHeaders, "collectables");
		int completionTime = mustHave(clHeaders, "completion_time");
		int maxRequired = max(name, continent, score, maxHealth, collectables, completionTime);

		int invalidRows = 0;

		//reading each lines
		for (int count = 0; sc.hasNextLine(); count++) {
		    String line = sc.nextLine();
		    //In case the attacker tries to break it by putting in too much data
		    if (count > 10000) {
			throw new IOException("Too much data inputs");
		    }
		    //Skip rows that is too long.
		    if (line.length() > 10000) {
			invalidRows++;
			continue;
		    }
		    String[] row = line.split(",", -1);
		    //Skip rows that do not have all of the elements.
		    if (row.length <= maxRequired) {
			invalidRows++;
			continue;
		    }
		    try {
			//trimming
			String nameText = row[name].trim();
			String continentText = row[continent].trim().toUpperCase();
			String completionTimeText = row[completionTime].trim();
			//Skip if anything is empty
			if (nameText.isEmpty() || continentText.isEmpty()
				|| completionTimeText.isEmpty()) {
			    invalidRows++;
			    continue;
			}
			//add record
			addRecord(new GameRecord(nameText, GameRecord.Continent.valueOf(continentText), 
			Integer.parseInt(row[score].trim()), Integer.parseInt(row[maxHealth].trim()), 
			Integer.parseInt(row[collectables].trim()), completionTimeText));
		    } catch (NumberFormatException ne) {	//Skip rows where it is not parsed correctly
			invalidRows++;
		    } catch (IllegalArgumentException e) {	//Skip rows with Illegal data
			invalidRows++;
		    }
		}
		//Print number of invalid rows
		if (invalidRows > 0) {
			System.out.println("There are "+invalidRows+" invalid records.");
		}
	}
    }

    /**
    * Helper method to make sure the element exists for sure
    *
    * @param headers list of headers
    * @param name name of the element
    * @throw IllegalArumentException if the element is not found
    * @return the location of the element found
    */
    private int mustHave(Map<String, Integer> headers, String name) {
	String target = name.trim().toLowerCase();
	if (headers.containsKey(target)) {
		return headers.get(target);
	}
	throw new IllegalArgumentException(name + " is missing");
    }

    /**
    * Helper method to make sure the two elements exist for sure
    *
    * @param headers list of headers
    * @param name1 name of the first element
    * @param name2 name of the second element
    * @throw IllegalArumentException if the element is not found
    * @return the location of the element found
    */
    private int mustHaveTwo(Map<String, Integer> headers, String name1, String name2) {
	String target1 = name1.trim().toLowerCase();
	String target2 = name2.trim().toLowerCase();
	if (headers.containsKey(target1)) {
		return headers.get(target1);
	}
	if (headers.containsKey(target2)) {
		return headers.get(target2);
	}
	throw new IllegalArgumentException(name1 + " or " + name2 + " is missing");
    }


    /**
    * Helper Method to find the biggest value
    *
    * @param values multiple int values
    * @return m the biggest value among the values
    */
    private int max(int... values) {
	int m = Integer.MIN_VALUE;
	for (int i : values) {
	    if (i > m) {
		m = i;
	    }
	}
	return m;
    }

    /**
     * Retrieves a list of names from the tree passed to the constructor.
     * The records should be ordered by the record's collectables, and fall within
     * the specified range of collectable values.  This collectables range will
     * also be used by future calls to filterRecords and getTopTen.
     *
     * If a continent filter has been set using the filterRecords method
     * below, then only records that pass that filter should be included in the
     * list of names returned by this method.
     *
     * When null is passed as either the low or high argument to this method,
     * that end of the range is understood to be unbounded.  For example, a 
     * null argument for the high parameter means that there is no maximum 
     * collectables to include in the returned list.
     *
     * @param low is the minimum collectables of records in the returned list
     * @param high is the maximum collectables of records in the returned list
     * @return List of names for all records from low to high that pass any
     *     set filter, or an empty list when no such records can be found
     */
    @Override
    public List<String> getAndSetRange(Integer low, Integer high) {
	if (low != null && high != null && low > high) {
		throw new IllegalArgumentException("the low bound is higher than the high bound");
	}
	if (low == null) {
	    tree.setIteratorMin(null);
	} else {
	    tree.setIteratorMin(bound(low));
	}

	if (high == null) {
	    tree.setIteratorMax(null);
	} else {
	    tree.setIteratorMax(bound(high));
	}
	return listOfNamesFiltered();
    }

    /**
    * Helper method to set the bounds of the range.
    *
    * @param collectables is to set the min or max rocords to get stored.
    * @return GameRecord that will be used as a bound
    */
    private GameRecord bound(int collectables) {
	return new GameRecord("", GameRecord.Continent.AFRICA, 0, 0, collectables, "000:00:00");
    }

    /**
     * Retrieves a list of record names that have a continent that match the specified
     * continent.  
     * Similar to the getRange method: this list of record names should be ordered by the records'
     * collectables, and should only include records that fall within the specified
     * range of collectable values that was established by the most recent call
     * to getRange.  If getRange has not previously been called, then no low
     * or high collectable bound should be used.  The filter set by this method
     * will be used by future calls to the getRange and getTopTen methods.
     *
     * When null is passed as the continent to this method, then no 
     * continent filter should be used.  This clears the filter.
     *
     * @param continent filters returned record names to only include records that
     *     have a continent that match the specified value.
     * @return List of names for records that meet this filter requirement and
     *     are within any previously set collectables range, or an empty list
     *     when no such records can be found
     */
    @Override
    public List<String> applyAndSetFilter(GameRecord.Continent continent) {
	filter = continent;
	return listOfNamesFiltered();
    }

    /**
    * Helper Method to find the filtered names
    *
    * @return filtered list of names that is filered
    */
    private List<String> listOfNamesFiltered() {
	List<String> filtered = new ArrayList<>();
	for (GameRecord record : tree) {
	    if (record != null && (filter == null || record.getContinent() == filter)) {
		filtered.add(record.getName());
	    }
	}
	return filtered;
    }

    /**
     * This method returns a list of record names representing the top
     * ten fastest (lowest completion time) records that both fall within any attribute range specified
     * by the most recent call to getRange, and conform to any filter set by
     * the most recent call to filteredRecords.  The order of the record names 
     * in this returned list is up to you.
     *
     * If fewer than ten such records exist, return all of them.  And return an
     * empty list when there are no such records.
     *
     * @return List of ten fastest record names
     */
    @Override
    public List<String> getTopTen() {
	List<GameRecord> topTen = new ArrayList<>();
	for (GameRecord record : tree) {
	     if (record == null) {
		continue;
	     }
	     if (filter != null && record.getContinent() != filter) {
		continue;
	     }
	     insertIntoTopTen(topTen, record);
	}
	List<String> names = new ArrayList<>();
	for (GameRecord record : topTen) {
	     names.add(record.getName());
	}
	return names;
    }

    /**
    * Helper Method to insert a record into the top ten list
    *
    * @param top the top ten record list
    * @param record a record that will be inserted
    */
    private void insertIntoTopTen(List<GameRecord> top, GameRecord record) {
	int time = convertSec(record.getCompletionTime());
	int i = 0;
	while (i<top.size()){
	    GameRecord now = top.get(i);
	    int compareTime = convertSec(now.getCompletionTime());
	    if (time < compareTime) {
	    break;
	    }
	    if (time == compareTime && record.getName().compareTo(now.getName()) < 0) {
		break;
	    }
	    i++;
	}
	top.add(i, record);
	if (top.size() > 10) {
	    top.remove(10);
	}
    }

    /**
    * Helper Method to convert the record time into sec
    *
    * @param timeText the time that you want to convert it into seconds only
    * @return seconds converted by time,but if input is invalid, then Integer.MAX_VALUE
    */
    private int convertSec(String timeText) {
	if (timeText == null) {
	    return Integer.MAX_VALUE;
	}
	String[] parts = timeText.trim().split(":");
	if (parts.length != 3) {
	    return Integer.MAX_VALUE;
	}
	try {
	int hours = Integer.parseInt(parts[0]);
	int minutes = Integer.parseInt(parts[1]);
	int seconds = Integer.parseInt(parts[2]);
	if (hours < 0 || minutes < 0 || seconds < 0) {
	    return Integer.MAX_VALUE;
	}
	return hours * 3600 + minutes * 60 + seconds;
	} catch (Exception e) {
	return Integer.MAX_VALUE;
	}
    }

}

