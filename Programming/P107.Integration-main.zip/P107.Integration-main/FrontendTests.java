import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Scanner;

import org.junit.jupiter.api.Test;

/**
 * Frontend tests for CS400 Project 1 (Role: Frontend).
 * Note: Place junit5.jar outside this folder and run tests with ../junit5.jar
 */
public class FrontendTests {

    /**
     * roleTest1: verifies that help prints command instructions.
     */
    @Test
    public void roleTest1() {
        BackendInterface backend = new Backend_Placeholder(new Tree_Placeholder());
        FrontendInterface fe = new Frontend(new Scanner(System.in), backend);

        String out = captureStdout(() -> fe.processSingleCommand("help"));
        assertTrue(out.toLowerCase().contains("commands"), "Help should print a commands header");
        assertTrue(out.toLowerCase().contains("submit"), "Help should mention submit");
        assertTrue(out.toLowerCase().contains("show"), "Help should mention show");
    }

    /**
     * roleTest2: verifies submit (single) + show MAX_COUNT prints some records.
     * With Backend_Placeholder, addRecord inserts a hard-coded name: ne0nVandal.
     */
    @Test
    public void roleTest2() {
        BackendInterface backend = new Backend_Placeholder(new Tree_Placeholder());
        FrontendInterface fe = new Frontend(new Scanner(System.in), backend);

        // submit a record (placeholder backend ignores parameters but inserts ne0nVandal)
        String out1 = captureStdout(() ->
            fe.processSingleCommand("submit Alice AFRICA 10 2 3 001:02:03")
        );
        assertTrue(out1.toLowerCase().contains("submitted"), "Submit should confirm submission");

        // show 5 should print the inserted name (via backend.getTopTen)
        String out2 = captureStdout(() -> fe.processSingleCommand("show 5"));
        assertTrue(out2.contains("ne0nVandal") || out2.toLowerCase().contains("no records") == false,
                "Show should print records and likely include ne0nVandal after submit");
    }

    /**
     * roleTest3: covers submit multiple, collectables, location, and show fastest times.
     * With Backend_Placeholder, readData inserts voidR1fter.
     */
    @Test
    public void roleTest3() {
        BackendInterface backend = new Backend_Placeholder(new Tree_Placeholder());
        FrontendInterface fe = new Frontend(new Scanner(System.in), backend);

        // submit multiple
        String outLoad = captureStdout(() -> fe.processSingleCommand("submit multiple records.csv"));
        assertTrue(outLoad.toLowerCase().contains("loaded"), "submit multiple should confirm load");

        // collectables max
        String outRange1 = captureStdout(() -> fe.processSingleCommand("collectables 150"));
        assertTrue(outRange1.toLowerCase().contains("range set"), "collectables MAX should update range");

        // collectables min to max
        String outRange2 = captureStdout(() -> fe.processSingleCommand("collectables 10 to 200"));
        assertTrue(outRange2.toLowerCase().contains("range set"), "collectables MIN to MAX should update range");

        // location filter
        String outLoc = captureStdout(() -> fe.processSingleCommand("location antarctica"));
        assertTrue(outLoc.toLowerCase().contains("filter set"), "location should confirm filter update");

        // show fastest times should print names including voidR1fter after submit multiple
        String outShow = captureStdout(() -> fe.processSingleCommand("show fastest times"));
        assertTrue(outShow.contains("voidR1fter") || outShow.contains("ne0nVandal") || outShow.toLowerCase().contains("no records") == false,
                "show fastest times should print records (likely voidR1fter after load)");
    }

    private static String captureStdout(Runnable action) {
        PrintStream oldOut = System.out;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(baos);
        System.setOut(ps);
        try {
            action.run();
        } finally {
            System.out.flush();
            System.setOut(oldOut);
        }
        return baos.toString();
    }
}
