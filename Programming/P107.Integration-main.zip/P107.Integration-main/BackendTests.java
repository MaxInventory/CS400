import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.io.File;
import java.io.PrintWriter;
import java.util.List;
import java.util.Scanner;

public class BackendTests {
    
    /**
    * This roleTest1 checks if addRecord() works successfully, and
    * getAndSetRange() returns a name inserted.
    *
    * @returns true if the tests pass, else false
    */
    @Test
    public void roleTest1() {
	IterableSortedCollection<GameRecord> tree = new Tree_Placeholder();
	Backend test = new Backend(tree);
	GameRecord record = new GameRecord("Jihun", GameRecord.Continent.ASIA, 100, 50, 3, "000:20:00");
	test.addRecord(record);
	List<String> names = test.getAndSetRange(null, null);
	assertNotNull(names);
	assertTrue(names.contains("Jihun"));
    }

    /**
    * This roleTest 2 checks if readData() can load the record.csv file
    * , and use applyAndSetFilter() to return filtered results
    *
    * @returns true if the tests passes, else false
    */
    @Test
    public void roleTest2() throws Exception {
	IterableSortedCollection<GameRecord> tree = new Tree_Placeholder();
	Backend test = new Backend(tree);
	File f = File.createTempFile("test_records", ".csv");
	f.deleteOnExit();
	try (PrintWriter wf = new PrintWriter(f)) {
	    wf.println("name,continent,score,max_health,damage_taken,damage_given,collectables,level,completion_time");
	    wf.println("Jihun,ASIA,100,50,15,80,7,1,000:20:00");
	    wf.println("Max,NORTH_AMERICA,200,60,30,100,9,1,000:22:00");
	}
	test.readData(f.getPath());
	List<String> filtered = test.applyAndSetFilter(GameRecord.Continent.NORTH_AMERICA);
	assertNotNull(filtered);
	assertTrue(filtered.contains("Max"));
	assertFalse(filtered.contains("Jihun"));
    }


    /**
    * This roleTest 3 checks if getTopTen() works correctly after
    * setting a range and filter.
    *
    * @returns true if the tests passes, else false
    */
    @Test
    public void roleTest3() {
	IterableSortedCollection<GameRecord> tree = new Tree_Placeholder();
	Backend test = new Backend(tree);
	test.addRecord(new GameRecord("Jihun", GameRecord.Continent.ASIA, 1, 1, 1, "000:20:00"));
	test.addRecord(new GameRecord("Jay", GameRecord.Continent.ASIA, 1, 1, 2, "000:21:00"));
	test.addRecord(new GameRecord("David", GameRecord.Continent.NORTH_AMERICA, 1, 1, 3, "000:20:30"));
	test.addRecord(new GameRecord("Mark", GameRecord.Continent.NORTH_AMERICA, 1, 1, 3, "000:23:30"));
	test.addRecord(new GameRecord("May", GameRecord.Continent.ASIA, 1, 1, 3, "000:21:30"));
	test.addRecord(new GameRecord("Will", GameRecord.Continent.NORTH_AMERICA, 1, 1, 3, "000:23:32"));
	test.addRecord(new GameRecord("Charles", GameRecord.Continent.NORTH_AMERICA, 1, 1, 3, "000:22:30"));
	test.addRecord(new GameRecord("Park", GameRecord.Continent.ASIA, 1, 1, 3, "000:25:30"));
	test.addRecord(new GameRecord("Cha", GameRecord.Continent.ASIA, 1, 1, 3, "000:25:00"));
	test.addRecord(new GameRecord("Andrew", GameRecord.Continent.NORTH_AMERICA, 1, 1, 3, "000:25:15"));
	test.addRecord(new GameRecord("Lin", GameRecord.Continent.ASIA, 1, 1, 3, "000:25:20"));
	test.getAndSetRange(1,10);
	test.applyAndSetFilter(GameRecord.Continent.ASIA);
	List<String> topTen = test.getTopTen();
	assertNotNull(topTen);
	assertTrue(topTen.size() <= 10);
	assertFalse(topTen.contains("David"));
	assertFalse(topTen.contains("Mark"));

    }


    /**
    *  This passARecordIntegration checks if the frontend can pass on a record
    *  to the backend and store it. Also, if it can display the record by the show
    *  command
    *
    *  @returns true if the tests passes, else false
    */
    @Test
    public void passARecordIntegration() {
	//Using TextUITester for this test
	TextUITester tester = new TextUITester("submit Jihun ASIA 1 1 1 000:20:00\n"
						+ "show fastest times\n"
						+ "quit\n");
	//Objects to be used in the testing (tree, backend, frontend, Scanner)
	IterableSortedCollection<GameRecord> tree = new RBTreeIterable<>();
        BackendInterface backend = new Backend(tree);
	Scanner sc = new Scanner(System.in);
	FrontendInterface frontend = new Frontend(sc, backend);

	//Checking for the record
	frontend.runCommandLoop();
	String check = tester.checkOutput();
	assertTrue(check.contains("Submitted record for: Jihun"));
	assertTrue(check.contains("1. Jihun"));
    }


    /**
    *  This loadAndFilterIntegration checks if the app (backend and frontend integrated)
    *  can load records and filtered by continent. 
    *
    *  @returns true if the tests passes, else false
    */
    @Test
    public void loadAndFilterIntegration() throws Exception {
	//records to test
	File f = createCSV(new String[] {"Jihun,ASIA,100,10,1,000:20:00",
				"Charles,NORTH_AMERICA,90,9,3,000:19:00",
				"Jay,ASIA,110,11,2,000:19:30"});

	//Using TextUITester for this test
	TextUITester tester = new TextUITester("submit multiple " + f.getAbsolutePath() + "\n"
						+ "location ASIA\n"
						+ "show 5\n"
						+ "quit\n");

	//Objects to be used in the testing (tree, backend, frontend, Scanner)
	IterableSortedCollection<GameRecord> tree = new RBTreeIterable<>();
        BackendInterface backend = new Backend(tree);
	Scanner sc = new Scanner(System.in);
	FrontendInterface frontend = new Frontend(sc, backend);

	//check for loaded records and if the filter have been applied properly
	frontend.runCommandLoop();
	String check = tester.checkOutput();
	assertTrue(check.contains("Loaded records from: " + f.getAbsolutePath()));
	assertTrue(check.contains("Location filter set: ASIA"));
	assertTrue(check.contains("Jihun"));
	assertTrue(check.contains("Jay"));
	assertFalse(check.contains("Charles"));
    }


    /**
    *  This is a helper method that creates a CSV file.
    *
    *  @param dataset that should be in the CSV file
    *  @return a CSV file
    *  @throws Exception if file cannot be created
    */
    private File createCSV(String[] dataset) throws Exception {
	File f = File.createTempFile("recordsForTest", ".csv");
	f.deleteOnExit();
	try (PrintWriter pw = new PrintWriter(f)) {
	    pw.println("name,continent,score,damage_taken,collectables,completion_time");
	    for (String data : dataset) {
		pw.println(data);
	    }
	}
	return f;
    }

    /**
    *  This setRangeIntegration checks if the app (backend and frontend intergrated)
    *  shows the records after the range is set.
    *
    *  @returns true if the tests passes, else false
    */
    @Test
    public void setRangeIntegration() throws Exception{
	//records to test
	File f = createCSV(new String[] {"Jihun,ASIA,100,10,1,000:20:00",
				"Charles,NORTH_AMERICA,100,10,3,000:21:00",
				"Jay,ASIA,100,10,5,000:22:00"});

	//Using TextUITester for this test
	TextUITester tester = new TextUITester("submit multiple " + f.getAbsolutePath() + "\n"
						+ "collectables 2 to 4\n"
						+ "show fastest times\n"
						+ "quit\n");

	//Objects to be used in the testing (tree, backend, frontend, Scanner)
	IterableSortedCollection<GameRecord> tree = new RBTreeIterable<>();
        BackendInterface backend = new Backend(tree);
	Scanner sc = new Scanner(System.in);
	FrontendInterface frontend = new Frontend(sc, backend);


	//check for loaded records and if the filter have been applied properly
	frontend.runCommandLoop();
	String check = tester.checkOutput();
	assertTrue(check.contains("Collectables range set: 2 to 4"));
	assertTrue(check.contains("Charles"));
	assertFalse(check.contains("Jay"));
	assertFalse(check.contains("Jihun"));
    }

    /**
    *  This fileNotExistIntegration checks if the frontend gets to backend
    *  to load a not existing file, it results in error.
    *
    *  @returns true if the tests passes, else false
    */
    @Test
    public void fileNotExistIntegration() {
	//file that do not exist
	String file = "doNotExist.csv";

	//Using TextUITester for this test
	TextUITester tester = new TextUITester("submit multiple " + file + "\n"
						+ "quit\n");

	//Objects to be used in the testing (tree, backend, frontend, Scanner)
	IterableSortedCollection<GameRecord> tree = new RBTreeIterable<>();
        BackendInterface backend = new Backend(tree);
	Scanner sc = new Scanner(System.in);
	FrontendInterface frontend = new Frontend(sc, backend);

	//check if it prints out error
	frontend.runCommandLoop();
	String check = tester.checkOutput();
	assertTrue(check.contains("Error: Could not read data from '" + file + "'"));
    }
}
