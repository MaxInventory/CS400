import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.io.File;
import java.io.PrintWriter;
import java.util.List;

public class BackendTests {
    
    /**
    * This roleTest1 checks if addRecord() works successfully, and
    * getAndSetRange() returns a name inserted.
    *
    * @returns true if the tests pass, else false
    */
    @Test
    public void roleTest1() {
	IterableSortedCollection<GameRecord> tree = new Tree_Placeholder();
	Backend test = new Backend(tree);
	GameRecord record = new GameRecord("Jihun", GameRecord.Continent.ASIA, 100, 50, 3, "000:20:00");
	test.addRecord(record);
	List<String> names = test.getAndSetRange(null, null);
	assertNotNull(names);
	assertTrue(names.contains("Jihun"));
    }

    /**
    * This roleTest 2 checks if readData() can load the record.csv file
    * , and use applyAndSetFilter() to return filtered results
    *
    * @returns true if the tests passes, else false
    */
    @Test
    public void roleTest2() throws Exception {
	IterableSortedCollection<GameRecord> tree = new Tree_Placeholder();
	Backend test = new Backend(tree);
	File f = File.createTempFile("test_records", ".csv");
	f.deleteOnExit();
	try (PrintWriter wf = new PrintWriter(f)) {
	    wf.println("name,continent,score,max_health,damage_taken,damage_given,collectables,level,completion_time");
	    wf.println("Jihun,ASIA,100,50,15,80,7,1,000:20:00");
	    wf.println("Max,NORTH_AMERICA,200,60,30,100,9,1,000:22:00");
	}
	test.readData(f.getPath());
	List<String> filtered = test.applyAndSetFilter(GameRecord.Continent.NORTH_AMERICA);
	assertNotNull(filtered);
	assertTrue(filtered.contains("Max"));
	assertFalse(filtered.contains("Jihun"));
    }


    /**
    * This roleTest 3 checks if getTopTen() works correctly after
    * setting a range and filter.
    *
    * @returns true if the tests passes, else false
    */
    @Test
    public void roleTest3() {
	IterableSortedCollection<GameRecord> tree = new Tree_Placeholder();
	Backend test = new Backend(tree);
	test.addRecord(new GameRecord("Jihun", GameRecord.Continent.ASIA, 1, 1, 1, "000:20:00"));
	test.addRecord(new GameRecord("Jay", GameRecord.Continent.ASIA, 1, 1, 2, "000:21:00"));
	test.addRecord(new GameRecord("David", GameRecord.Continent.NORTH_AMERICA, 1, 1, 3, "000:20:30"));
	test.addRecord(new GameRecord("Mark", GameRecord.Continent.NORTH_AMERICA, 1, 1, 3, "000:23:30"));
	test.addRecord(new GameRecord("May", GameRecord.Continent.ASIA, 1, 1, 3, "000:21:30"));
	test.addRecord(new GameRecord("Will", GameRecord.Continent.NORTH_AMERICA, 1, 1, 3, "000:23:32"));
	test.addRecord(new GameRecord("Charles", GameRecord.Continent.NORTH_AMERICA, 1, 1, 3, "000:22:30"));
	test.addRecord(new GameRecord("Park", GameRecord.Continent.ASIA, 1, 1, 3, "000:25:30"));
	test.addRecord(new GameRecord("Cha", GameRecord.Continent.ASIA, 1, 1, 3, "000:25:00"));
	test.addRecord(new GameRecord("Andrew", GameRecord.Continent.NORTH_AMERICA, 1, 1, 3, "000:25:15"));
	test.addRecord(new GameRecord("Lin", GameRecord.Continent.ASIA, 1, 1, 3, "000:25:20"));
	test.getAndSetRange(1,10);
	test.applyAndSetFilter(GameRecord.Continent.ASIA);
	List<String> topTen = test.getTopTen();
	assertNotNull(topTen);
	assertTrue(topTen.size() <= 10);
	assertFalse(topTen.contains("David"));
	assertFalse(topTen.contains("Mark"));

    }

}
