import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

public class FrontendTests {

    /**
     * This roleTest1 checks if generateShortestPathPromptHTML() contains
     * text input fields with the correct id, and correct button label
     * 
     * @return true if the tests pass, else false
     */
    @Test
    public void roleTest1() {
	GraphADT<String,Double> graph = new Graph_Placeholder();
        BackendInterface backend = new Backend_Placeholder(graph);
        Frontend frontend = new Frontend(backend);

        String html = frontend.generateShortestPathPromptHTML();

        assertTrue(html.contains("id=\"start\""));
        assertTrue(html.contains("id=\"end\""));
        assertTrue(html.contains("Start Location"));
        assertTrue(html.contains("End Location"));
        assertTrue(html.contains("Find Shortest Path"));
    }

    /**
     * This roleTest2 checks if generateShortestPathResponseHTML(start, end) contains
     * total time and list of locations in order.
     * 
     * @return true if the tests pass, else false
     */
    @Test
    public void roleTest2() {
        GraphADT<String,Double> graph = new Graph_Placeholder();
	BackendInterface backend = new Backend_Placeholder(graph);
        Frontend frontend = new Frontend(backend);

        String start = "A";
        String end = "E";

        List<String> locations = backend.findLocationsOnShortestPath(start, end);
        List<Double> times = backend.findTimesOnShortestPath(start, end);

        String html = frontend.generateShortestPathResponseHTML(start, end);

        if (locations == null || locations.size() == 0) {
            assertTrue(html.contains("<p>"));
        } else {
            assertTrue(html.contains("<p>"));
            assertTrue(html.contains("<ol>"));
            assertTrue(html.contains("</ol>"));
            assertTrue(html.contains("Total time:"));

            for (String location : locations) {
                assertTrue(html.contains(location));
            }

            double total = 0.0;
            if (times != null) {
                for (Double time : times) {
                    total += time;
                }
            }
            assertTrue(html.contains("" + total));
        }
    }

    /**
     * This roleTest3 checks if generateReachableFromWithinResponseHTML(start, maxTime)
     * contains the correct text input fields, button labels, and the elements that
     * response HTML have to include
     * 
     * @return true if the tests pass, else false
     */
    @Test
    public void roleTest3() {
	GraphADT<String,Double> graph = new Graph_Placeholder();
        BackendInterface backend = new Backend_Placeholder(graph);
        Frontend frontend = new Frontend(backend);

        String promptHTML = frontend.generateReachableFromWithinPromptHTML();
        assertTrue(promptHTML.contains("id=\"from\""));
        assertTrue(promptHTML.contains("id=\"time\""));
        assertTrue(promptHTML.contains("Start Location"));
        assertTrue(promptHTML.contains("Max Time"));
        assertTrue(promptHTML.contains("Reachable From Within"));

        String start = "A";
        double maxTime = 60.0;
        String responseHTML = frontend.generateReachableFromWithinResponseHTML(start, maxTime);

        assertTrue(responseHTML.contains("<p>") || responseHTML.contains("<ul>"));

        try {
            List<String> locations = backend.getReachableFromWithin(start, maxTime);

            if (locations == null || locations.size() == 0) {
                assertTrue(responseHTML.contains("No locations") || responseHTML.contains("Error"));
            } else {
                assertTrue(responseHTML.contains("<ul>"));
                assertTrue(responseHTML.contains("</ul>"));
                for (String location : locations) {
                    assertTrue(responseHTML.contains(location));
                }
            }
        } catch (Exception e) {
            assertTrue(responseHTML.contains("Error"));
        }
    }

//////////////////////////////////////IntegrationTests/////////////////////////////////////////////

    	/**
        * This shortestPathResponseIntegrationTest checks if
        * generateShortestPathResponseHTML(start, end) returns a response that contains
        * the proper path and total time in an integration setting.
	*
	* @return true if the tests pass, else false
        */
        @Test
        public void shortestPathResponseIntegrationTest() {
                // Graph to use for the test.
                GraphADT<String, Double> graph = new DijkstraGraph<>();
                BackendInterface backend = new Backend(graph);
                Frontend frontend = new Frontend(backend);
                graph.insertNode("A");
                graph.insertNode("B");
                graph.insertNode("C");
                graph.insertNode("D");
                graph.insertEdge("A", "B", 2.0);
                graph.insertEdge("B", "C", 3.0);
                graph.insertEdge("C", "D", 4.0);
                graph.insertEdge("A", "D", 20.0);

                String html = frontend.generateShortestPathResponseHTML("A", "D");

                // Check if it includes the correct shortest path and total time.
                assertTrue(html.contains("<p>"));
                assertTrue(html.contains("<ol>"));
                assertTrue(html.contains("A"));
                assertTrue(html.contains("B"));
                assertTrue(html.contains("C"));
                assertTrue(html.contains("D"));
                assertTrue(html.contains("Total time:"));
                assertTrue(html.contains("9.0"));
        }
        
        /**
        * This shortestPathNoPathIntegrationTest checks if
        * generateShortestPathResponseHTML(start, end) returns a response
        * when there is no path between two locations without crashing in an integration setting.
        *
        * @return true if tests pass, else false
        */
        @Test
        public void shortestPathNoPathIntegrationTest() {
                // Graph to use for the test.
                GraphADT<String, Double> graph = new DijkstraGraph<>();
                BackendInterface backend = new Backend(graph);
                Frontend frontend = new Frontend(backend);
                //No Path between A and B.
                graph.insertNode("A");
                graph.insertNode("B");

                String html = frontend.generateShortestPathResponseHTML("A", "B");

                // Check if the frontend handles the no-path case.
                assertNotNull(html);
                assertTrue(html.contains("<p>"));
                assertTrue(html.contains("Error") || html.contains("No") || html.length() > 0);
        }

         /**
        * This reachableFromWithinResponseIntegrationTest checks if
        * generateReachableFromWithinResponseHTML(start, maxTime) return a response
        * with reachable locations in an integration setting.
        *
        * @return true if tests pass, else false
        */
        @Test
        public void reachableFromWithinResponseIntegrationTest() {
                // Graph to use for the test.
                GraphADT<String, Double> graph = new DijkstraGraph<>();
                BackendInterface backend = new Backend(graph);
                Frontend frontend = new Frontend(backend);
                graph.insertNode("A");
                graph.insertNode("B");
                graph.insertNode("C");
                graph.insertNode("D");
                graph.insertEdge("A", "B", 2.0);
                graph.insertEdge("B", "C", 2.0);
                graph.insertEdge("C", "D", 5.0);

                String html = frontend.generateReachableFromWithinResponseHTML("A", 4.0);
                List<String> reachable = backend.getReachableFromWithin("A", 4.0);

                // Check if the response includes all reachable results.
                assertTrue(html.contains("<p>") || html.contains("<ul>"));
                assertNotNull(reachable);
                for (String location : reachable) {
                        assertTrue(html.contains(location));
                }
        }

        /**
        * This loadedGraphShortestPathIntegrationTest checks if the frontend works
        * after the backend loads graph data from a dot file in an integration setting.
        * Also, checks if the frontend can generate a response from loaded data.
        *
        * @return true if tests pass, else false
        */
        @Test
        public void loadedGraphShortestPathIntegrationTest() {
                // Graph to use for the test.
                GraphADT<String, Double> graph = new DijkstraGraph<>();
                BackendInterface backend = new Backend(graph);
                Frontend frontend = new Frontend(backend);

                // Load graph data through backend.
                try {
                        backend.loadGraphData("europeanRail.dot");
                } catch (Exception e) {
                        fail("Exception thrown while loading graph data.");
                }

                // Execute generateShortestPathResponseHTML().
                String html = frontend.generateShortestPathResponseHTML("Amsterdam", "London");

                // Check if a response is generated.
                assertNotNull(html);
                assertTrue(html.contains("<p>"));
                assertTrue(html.length() > 0);
                assertTrue(html.contains("Amsterdam"));
                assertTrue(html.contains("London"));
        }






}
