import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.io.File;
import java.util.Scanner;

/**
 * This class makes use of a GraphADT to perform shortest path computations.
 */
public class Backend implements BackendInterface {

    private GraphADT<String, Double> graph;
    private List<String> nodes;

    /**
     * Constructor
     * 
     * @param graph object to store the backend's graph data
     */
    public Backend(GraphADT<String, Double> graph) {
        this.graph = graph;
        this.nodes = new ArrayList<>();
    }

    /**
     * Loads graph data from a dot file. If a graph was previously loaded, this
     * method should first delete the contents (nodes and edges) of the existing
     * graph before loading a new one.
     * 
     * @param filename the path to a dot file to read graph data from
     * @throws IOException if there was any problem reading from this file
     */
    public void loadGraphData(String filename) throws IOException {
        // Improvement (MILGRAM2): Clear the graph based on its actual nodes, not just our list
        try {
            List<String> allNodes = graph.getAllNodes();
            if (allNodes != null) {
                for (String node : allNodes) {
                    graph.removeNode(node);
                }
            }
        } catch (UnsupportedOperationException e) {
            // Fallback for placeholders or if method not implemented
            for (String node : nodes) {
                graph.removeNode(node);
            }
        }
        nodes.clear();

        File file = new File(filename);
        boolean hasHeader = false;
        boolean hasFooter = false;

        try (Scanner sc = new Scanner(file)) {
            int lineNum = 0;
            while (sc.hasNextLine()) {
                lineNum++;
                String line = sc.nextLine().trim();
                if (line.isEmpty()) continue;
                
                if (line.startsWith("digraph")) {
                    hasHeader = true;
                    continue;
                }
                if (line.equals("}")) {
                    hasFooter = true;
                    continue;
                }
                
                parseAndInsertEdge(line, lineNum);
            }
        }
        
        // Improvement (MILGRAM2): Validate .dot file structure
        if (!hasHeader || !hasFooter) {
            throw new IOException("Invalid .dot file format: missing digraph header or closing brace.");
        }
    }

    /**
     * Helper method to parse a line from a dot file and insert the edge into the graph.
     * 
     * @param line the line to parse
     * @param lineNum the line number for error reporting
     * @throws IOException if parsing fails
     */
    private void parseAndInsertEdge(String line, int lineNum) throws IOException {
        if (line.contains("->") && line.contains("[minutes=")) {
            int firstQuote = line.indexOf("\"");
            int secondQuote = line.indexOf("\"", firstQuote + 1);
            if (firstQuote != -1 && secondQuote != -1) {
                String source = line.substring(firstQuote + 1, secondQuote);

                int thirdQuote = line.indexOf("\"", secondQuote + 1);
                int fourthQuote = line.indexOf("\"", thirdQuote + 1);
                if (thirdQuote != -1 && fourthQuote != -1) {
                    String dest = line.substring(thirdQuote + 1, fourthQuote);

                    // Improvement (YCHANG326): Fix index bug
                    int minIndex = line.indexOf("[minutes=");
                    if (minIndex != -1) {
                        int minStart = minIndex + 9;
                        int minEnd = line.indexOf("]", minStart);
                        if (minEnd != -1) {
                            String weightStr = line.substring(minStart, minEnd);
                            try {
                                double weight = Double.parseDouble(weightStr);

                                if (!nodes.contains(source)) {
                                    nodes.add(source);
                                    graph.insertNode(source);
                                }
                                if (!nodes.contains(dest)) {
                                    nodes.add(dest);
                                    graph.insertNode(dest);
                                }
                                graph.insertEdge(source, dest, weight);
                            } catch (NumberFormatException e) {
                                // Improvement (YCHANG326 & CHUNG92): Throw descriptive exception
                                throw new IOException("Malformed weight data on line " + lineNum + ": \"" + weightStr + "\"");
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Returns a list of all locations in the graph.
     * 
     * @return list of all location names
     */
    public List<String> getListOfAll() {
        return new ArrayList<>(nodes);
    }

    /**
     * Return the sequence of locations along the shortest path from start to
     * end, or an empty list if no such path exists.
     * 
     * @param start the start of the path
     * @param end   the end of the path
     * @return a list with the nodes along the shortest path from start to end,
     *         or an empty list if no such path exists
     */
    public List<String> findLocationsOnShortestPath(String start, String end) {
        try {
            return graph.shortestPathData(start, end);
        } catch (NoSuchElementException e) {
            return new ArrayList<>();
        }
    }

    /**
     * Return the times in minutes between each two nodes on the shortest path
     * from start to end, or an empty list if no such path exists.
     * 
     * @param start the start of the path
     * @param end   the end of the path
     * @return a list with the times in minutes between two nodes along the
     *         shortest path from start to end, or an empty list if no such path
     *         exists
     */
    public List<Double> findTimesOnShortestPath(String start, String end) {
        List<Double> times = new ArrayList<>();
        try {
            List<String> path = graph.shortestPathData(start, end);
            // The path list has N nodes, so there are N-1 edges between them
            for (int i = 0; i < path.size() - 1; i++) {
                times.add(graph.getEdge(path.get(i), path.get(i + 1)));
            }
        } catch (NoSuchElementException e) {
            // Path does not exist or nodes not found
        }
        return times;
    }

    /**
     * Returns the list of locations that can be reached when starting from the
     * provided start, and travelling maxTime in minutes.
     * 
     * @param start   the location to find the reachable locations from
     * @param maxTime is the maximum time it can take to get from from the
     *                start to report a location
     * @return the list of locations that can be reached from start in maxTime
     *         or fewer minutes
     * @throws NoSuchElementException if start does not exist
     */
    public List<String> getReachableFromWithin(String start, double maxTime) throws NoSuchElementException {
        if (!graph.containsNode(start)) {
            throw new NoSuchElementException("Start node does not exist in graph");
        }

        List<String> reachable = new ArrayList<>();
        for (String node : nodes) {
            // Improvement (MILGRAM2): Exclude the start node from results
            if (node.equals(start)) {
                continue;
            }
            try {
                if (graph.shortestPathCost(start, node) <= maxTime) {
                    reachable.add(node);
                }
            } catch (NoSuchElementException e) {
                // Ignore unreachable nodes
            }
        }
        return reachable;
    }
}
