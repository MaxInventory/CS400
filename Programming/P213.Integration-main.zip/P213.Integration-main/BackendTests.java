import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class BackendTests {

    /**
     * roleTest1 tests the loadGraphData and getListOfAll methods.
     * It creates a temporary minimal dot file, loads it, and asserts that
     * the list of nodes reflects the inserted nodes.
     */
    @Test
    public void roleTest1() {
        Graph_Placeholder graph = new Graph_Placeholder();
        Backend backend = new Backend(graph);
        File tempFile = null;
        try {
            tempFile = File.createTempFile("testGraph", ".dot");
            try (FileWriter writer = new FileWriter(tempFile)) {
                writer.write("digraph test {\n");
                writer.write("    \"A\" -> \"B\" [minutes=10];\n");
                writer.write("    \"B\" -> \"C\" [minutes=20];\n");
                writer.write("}\n");
            }

            backend.loadGraphData(tempFile.getAbsolutePath());
            List<String> allNodes = backend.getListOfAll();

            assertTrue(allNodes.contains("A"), "Node A should be loaded");
            assertTrue(allNodes.contains("B"), "Node B should be loaded");
            assertTrue(allNodes.contains("C"), "Node C should be loaded");
            assertEquals(3, allNodes.size(), "There should be exactly 3 nodes");

        } catch (IOException e) {
            fail("IOException thrown: " + e.getMessage());
        } finally {
            if (tempFile != null && tempFile.exists()) {
                tempFile.delete();
            }
        }
    }

    /**
     * roleTest2 tests the findLocationsOnShortestPath and
     * findTimesOnShortestPath methods. It relies on the Graph_Placeholder
     * hardcoded behavior for shortestPathData which captures nodes between start
     * and end.
     */
    @Test
    public void roleTest2() {
        Graph_Placeholder graph = new Graph_Placeholder();
        Backend backend = new Backend(graph);

        // From Graph_Placeholder:
        // path = ["Union South", "Computer Sciences and Statistics", "Weeks Hall for
        // Geological Sciences"]
        String start = "Union South";
        String end = "Weeks Hall for Geological Sciences";

        List<String> pathLocations = backend.findLocationsOnShortestPath(start, end);
        assertEquals(3, pathLocations.size(), "Path should have 3 locations");
        assertEquals("Union South", pathLocations.get(0));
        assertEquals("Computer Sciences and Statistics", pathLocations.get(1));
        assertEquals("Weeks Hall for Geological Sciences", pathLocations.get(2));

        List<Double> pathTimes = backend.findTimesOnShortestPath(start, end);
        assertEquals(2, pathTimes.size(), "Path should have 2 edges/times");
        assertEquals(1.0, pathTimes.get(0));
        assertEquals(2.0, pathTimes.get(1));
    }

    /**
     * roleTest3 tests the getReachableFromWithin method.
     * The placeholder returns cost based on indices. We insert some manual
     * dummy nodes into the backend using loadGraphData to have nodes to check.
     */
    @Test
    public void roleTest3() {
        Graph_Placeholder graph = new Graph_Placeholder();
        Backend backend = new Backend(graph);
        File tempFile = null;
        try {
            tempFile = File.createTempFile("testReachable", ".dot");
            try (FileWriter writer = new FileWriter(tempFile)) {
                writer.write("digraph test {\n");
                writer.write("    \"Union South\" -> \"Computer Sciences and Statistics\" [minutes=5];\n");
                writer.write("}\n");
            }

            backend.loadGraphData(tempFile.getAbsolutePath());

            // start is Union South.
            // In placeholder shortestPathCost, if we start at Union South (index 0),
            // and end at Union South, cost is 0.
            // If we end at index 1 ("Computer Sciences and Statistics"), sum += 1 = 1.0.
            List<String> reachable = backend.getReachableFromWithin("Union South", 1.5);

            assertTrue(reachable.contains("Union South"));
            assertTrue(reachable.contains("Computer Sciences and Statistics"));

        } catch (IOException e) {
            fail("IOException thrown: " + e.getMessage());
        } finally {
            if (tempFile != null && tempFile.exists()) {
                tempFile.delete();
            }
        }
    }
}
