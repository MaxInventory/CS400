/*
 * Author: Jihun Chung 
 * Email: chung92@wisc.edu
 * Course: CS 400, Spring 2026
 * Assignment: P101.BinarySearchTree
 * 
 */

import java.util.Stack;

/**
 * This class represents Binary Search Tree.
 * The values will be stored in sorted order.
 * This class implements the SortedCollection Interface and use BinaryNodes.
 * It includes BST methods, a helper method, and test methods.
 * 
 * @param <T> the type of data that will be stored in the tree
 */

public class BinarySearchTree<T extends Comparable<T>> implements SortedCollection<T> {
	
	//Data Field
	protected BinaryNode<T> root;
	
	//Default Constructor
	public BinarySearchTree() {
		root = null;
	}
	
	/**
     * Performs the naive binary search tree insert algorithm to recursively
     * insert the provided newNode (which has already been initialized with a
     * data value) into the provided tree/subtree. When the provided subtree
     * is null, this method does nothing. 
     */
    protected void insertHelper(BinaryNode<T> newNode, BinaryNode<T> subtree) {
        if (subtree == null) {
        	return;
        }
        int where = newNode.getData().compareTo(subtree.getData());
        if (where <= 0) {
        	if (subtree.getLeft() == null) {
        		subtree.setLeft(newNode);
        		newNode.setUp(subtree);
        	} else {
        		insertHelper(newNode, subtree.getLeft());
        	}
        } else {
        	if (subtree.getRight() == null) {
        		subtree.setRight(newNode);
        		newNode.setUp(subtree);
        	} else {
        		insertHelper(newNode, subtree.getRight());
        	}
        }
    }
	
	/**
 	* Inserts newNode into this tree starting from the root.
 	*/
	protected void insertHelper(BinaryNode<T> newNode) {
    	if (newNode == null) {
			return;
		}
    	if (root == null) {
        	root = newNode;
        	newNode.setUp(null);
        	return;
    	}
    	insertHelper(newNode, root);
	}

    /**
     * Inserts a new data value into the sorted collection.
     * 
     * @param data the new value being inserted
     * @throws NullPointerException if data argument is null, we do not allow
     * null values to be stored within a SortedCollection
     */
	@Override
	public void insert(T data) throws NullPointerException {
		if (data == null) {
			throw new NullPointerException("data argument is null");
		}
		BinaryNode<T> newNode = new BinaryNode<>(data);
		if (root == null) {
			root = newNode;
			root.setUp(null);
			return;
		}
		insertHelper(newNode, root);
	}

	/**
     * Check whether data is stored in the tree.
     * 
     * @param find the value to check for in the collection
     * @return true if the collection contains data one or more times, 
     * and false otherwise
     */
	@Override
	public boolean contains(Comparable<T> find) {
		if (find == null) {
			throw new NullPointerException("find argument is null");
		}
		BinaryNode<T> check = root;
		while (check != null) {
			int where = find.compareTo(check.getData());
			if (where == 0) {
				return true;
			} else if (where < 0) {
				check = check.getLeft();
			} else {
				check = check.getRight();
			}
		}
		return false;
	}

	/**
     * Counts the number of values in the collection, with each duplicate value
     * being counted separately within the value returned.
     * 
     * @return the number of values in the collection, including duplicates
     */
	@Override
	public int size() {
		int counts = 0;
		Stack<BinaryNode<T>> stack = new Stack<>();
		if (root != null) {
			stack.push(root);
		}
		while (!stack.isEmpty()) {
			BinaryNode<T> node = stack.pop();
			counts++;
			if (node.getLeft() != null) {
				stack.push(node.getLeft());
			}
			if (node.getRight() != null) {
				stack.push(node.getRight());
			}
		}
		return counts;
	}

	/**
     * Checks if the collection is empty.
     * @return true if the collection contains 0 values, false otherwise
     */
	@Override
	public boolean isEmpty() {
		if (root == null) {
			return true;
		} else {
			return false;
		}
	}

	/**
     * Removes all values and duplicates from the collection.
     */
	@Override
	public void clear() {
		root = null;
	}
	
	//Test Methods (test1, test2, test3)
	
	public boolean test1() {
		boolean allPass = true;
		try {
			BinarySearchTree<Integer> tree = new BinarySearchTree<Integer>();
			if (!tree.isEmpty()) {
				allPass &= false;
			}
			if (tree.size() != 0) {
				allPass &= false;
			}
			tree.insert(8);
			tree.insert(5);
			tree.insert(1);
			tree.insert(7);
			tree.insert(10);
			
			if (tree.root == null) {
				allPass &= false;
			}
			if (tree.root.getLeft() == null || !tree.root.getLeft().getData().equals(5)) {
				allPass &= false;
			}
			if (tree.root.getRight() == null || !tree.root.getRight().getData().equals(10)) {
				allPass &= false;
			}
			if (!tree.root.toLevelOrderString().equals("[ 8, 5, 10, 1, 7 ]")) {
				allPass &= false;
			}
			if (!tree.root.toInOrderString().equals("[ 1, 5, 7, 8, 10 ]")) {
				allPass &= false;
			}
			if (!tree.contains(8) || !tree.contains(5)
					|| !tree.contains(1) || !tree.contains(7)
				|| !tree.contains(10)) {
				allPass &= false;
			}
		} catch (Exception e) {
			System.out.println("Error: "+ e.getMessage());
			return false;
		}
		return allPass;
	}
	
	public boolean test2() {
		boolean allPass = true;
		try {
			BinarySearchTree<Integer> tree = new BinarySearchTree<>();
			if (!tree.isEmpty()) {
				allPass &= false;
			}
			if (tree.size() != 0) {
				allPass &= false;
			}
			tree.insert(5);
			tree.insert(2);
			tree.insert(8);
			tree.insert(2);
			BinaryNode<Integer> rt = tree.root;
			if (rt == null || !rt.getData().equals(5)) {
				allPass &= false;
			}
			BinaryNode<Integer> left = rt.getLeft();
			if (left == null || !left.getData().equals(2)) {
				allPass &= false;
			}
			BinaryNode<Integer> leftRoot = left.getLeft();
			if (leftRoot == null || !leftRoot.getData().equals(2)) {
				allPass &= false;
			}
			if (left.getUp() != rt) {
				allPass &= false;
			}
			if (leftRoot.getUp() != left) {
				allPass &= false;
			}
			if (tree.size() != 4) {
				allPass &= false;
			}
		} catch (Exception e) {
			System.out.println("Error: "+ e.getMessage());
			allPass &= false;
		}
		return allPass;
	}
	
	public boolean test3() {
		boolean allPass = true;
		try {
			BinarySearchTree<String> tree = new BinarySearchTree<>();
			if (!tree.isEmpty()) {
				allPass &= false;
			}
			if (tree.size() != 0) {
				allPass &= false;
			}
			tree.insert("b");
			tree.insert("f");
			tree.insert("k");
			tree.insert("a");
			tree.insert("z");
			if (!tree.contains("b") || !tree.contains("f")
					|| !tree.contains("k") || !tree.contains("a")
				|| !tree.contains("z")) {
				allPass &= false;	
			}
			if (tree.size() != 5) {
				allPass &= false;
			}
			tree.clear();
			if (!tree.isEmpty()) {
				allPass &= false;
			}
			if (tree.size() != 0) {
				allPass &= false;
			}
			if (tree.root != null) {
				allPass &= false;
			}
		} catch (Exception e) {
			System.out.println("Error: "+ e.getMessage());
			allPass &= false;
		}
		return allPass;
	}
	
	public static void main(String[] args) {
		BinarySearchTree<Integer> intTest = new BinarySearchTree<>();
		System.out.println("test1: "+ (intTest.test1() ? "PASS" : "FAIL"));
		System.out.println("test2: "+ (intTest.test2() ? "PASS" : "FAIL"));
		BinarySearchTree<String> strTest = new BinarySearchTree<>();
		System.out.println("test3: "+ (strTest.test3() ? "PASS" : "FAIL"));
		
	}

}
