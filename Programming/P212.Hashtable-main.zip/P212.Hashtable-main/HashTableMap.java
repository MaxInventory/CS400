import java.util.LinkedList;
import java.util.List;
import java.util.NoSuchElementException;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class HashTableMap<KeyType, ValueType> implements MapADT<KeyType, ValueType> {

    protected class Pair {

        public KeyType key;
        public ValueType value;

        public Pair(KeyType key, ValueType value) {
            this.key = key;
            this.value = value;
        }

    }

    //data fields
    protected LinkedList<Pair>[] table = null;
    private int size = 0;

    //Default constructor
    public HashTableMap() {
        this(8);
    }

    //Constructor with parameter
    @SuppressWarnings("unchecked")
    public HashTableMap(int capacity) {
        if (capacity < 1) {
            throw new IllegalArgumentException("Capacity can't be less than 1.");
        }
        table = (LinkedList<Pair>[]) new LinkedList[capacity];
    }

    /**
     * Returns the key's index
     * 
     * @param key The key to find
     * @return index The key's index
     */
    private int getIndex(KeyType key) {
        int index = key.hashCode() % table.length;
        if (index < 0) {
            index += table.length;
        }
        return index;
    }

    /**
     * This helper method resizes the table by doubling its capacity.
     */
    @SuppressWarnings("unchecked")
    private void resizeToDoubleCap() {
        LinkedList<Pair>[] oldTable = table;
        table = (LinkedList<Pair>[]) new LinkedList[oldTable.length * 2];

        for (int i = 0; i < oldTable.length; i++) {
            if (oldTable[i] != null) {
                for (Pair pair : oldTable[i]) {
                    int index = pair.key.hashCode() % table.length;
                    if (index < 0) {
                        index += table.length;
                    }

                    if (table[index] == null) {
                        table[index] = new LinkedList<Pair>();
                    }

                    table[index].add(new Pair(pair.key, pair.value));
                }
            }
        }
    }

    /**
     * Adds a new key,value pair/mapping to this collection.
     * @param key the key of the key,value pair
     * @param value the value that key maps to (may be null)
     * @throws IllegalArgumentException if key already maps to a value without
     *         making any changes to the table
     * @throws NullPointerException if key is null
     */
    @Override
    public void put(KeyType key, ValueType value) throws IllegalArgumentException {
        if (key == null) {
            throw new NullPointerException("Key is null");
        }

        if (containsKey(key)) {
            throw new IllegalArgumentException("key already maps to a value");
        }

        if ((double) (size + 1) / table.length >= 0.75) {
            resizeToDoubleCap();
        }

        int index = getIndex(key);

        if (table[index] == null) {
            table[index] = new LinkedList<Pair>();
        }

        table[index].add(new Pair(key, value));
        size++;
    }

    /**
     * Checks whether a key maps to a value in this collection.
     * @param key the key to check
     * @throws NullPointerException if key is null
     * @return true if the key maps to a value, and false is the key doesn't
     *         map to a value
     */
    @Override
    public boolean containsKey(KeyType key) {
        if (key == null) {
            throw new NullPointerException("Key is null");
        }

        int index = getIndex(key);

        if (table[index] == null) {
            return false;
        }

        for (Pair pair : table[index]) {
            if (pair.key.equals(key)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Retrieves the specific value that a key maps to.
     * @param key the key to look up
     * @return the value that key maps to
     * @throws NoSuchElementException when key is not stored in this collection
     * @throws NullPointerException if key is null
     */
    @Override
    public ValueType get(KeyType key) throws NoSuchElementException {
        if (key == null) {
            throw new NullPointerException("Key is null");
        }

        int index = getIndex(key);

        if (table[index] != null) {
            for (Pair pair : table[index]) {
                if (pair.key.equals(key)) {
                    return pair.value;
                }
            }
        }

        throw new NoSuchElementException("Key is not stored in this collection");
    }

    /**
     * Remove the mapping for a key from this collection.
     * @param key the key whose mapping to remove
     * @return the value that the removed key mapped to
     * @throws NoSuchElementException when key is not stored in this collection
     * @throws NullPointerException if key is null
     */
    @Override
    public ValueType remove(KeyType key) throws NoSuchElementException {
        if (key == null) {
            throw new NullPointerException("Key is null");
        }

        int index = getIndex(key);

        if (table[index] == null) {
            throw new NoSuchElementException("table[index] is null");
        }

        for (int i = 0; i < table[index].size(); i++) {
            Pair pair = table[index].get(i);
            if (pair.key.equals(key)) {
                ValueType removedValue = pair.value;
                table[index].remove(i);
                size--;

                if (table[index].isEmpty()) {
                    table[index] = null;
                }

                return removedValue;
            }
        }

        throw new NoSuchElementException("Key is not stored in this collection");
    }

    /**
     * Removes all key,value pairs from this collection without changing the
     * capacity of the underlying array.
     */
    @Override
    public void clear() {
        for (int i = 0; i < table.length; i++) {
            table[i] = null;
        }
        size = 0;
    }

    /**
     * Retrieves the number of keys stored in this collection.
     * @return the number of keys stored in this collection
     */
    @Override
    public int getSize() {
        return size;
    }

    /**
     * Retrieves this collection's capacity.
     * @return the size of the underlying array for this collection
     */
    @Override
    public int getCapacity() {
        return table.length;
    }

    /**
     * Retrieves this collection's keys.
     * @return a list of keys in the underlying array for this collection
     */
    @Override
    public List<KeyType> getKeys() {
        List<KeyType> keys = new LinkedList<KeyType>();

        for (int i = 0; i < table.length; i++) {
            if (table[i] != null) {
                for (Pair pair : table[i]) {
                    keys.add(pair.key);
                }
            }
        }

        return keys;
    }

/////////////////////////////////////////////Tests////////////////////////////////////////////////
     /**
     * This basicFunctionTest checks if basic functions
     * (put, get, containsKey, and getSize)
     * works
     * 
     * @return true if the tests pass, else false
     */
    @Test
    public void basicFunctionTest() {
        // map with capacity of 4.
        HashTableMap<Integer, String> map = new HashTableMap<>(4);
        // Put 0 ("zero"), 1 ("one") in the map.
        map.put(0, "zero");
        map.put(1, "one");

        // Checking if the map contains the two keys.
        assertTrue(map.containsKey(0));
        assertTrue(map.containsKey(1));
        assertEquals("zero", map.get(0));
        assertEquals("one", map.get(1));

        // Checking if the size is 2.
        assertEquals(2, map.getSize());
    }

    /**
     * This removeTest checks if the remove() executes propertly.
     * 
     * @return true if the tests pass, else false
     */
    @Test
    public void removeTest() {
        // map with capacity of 4.
        HashTableMap<Integer, String> map = new HashTableMap<>(4);
        // Put 0 ("zero"), 1 ("one") in the map.
        map.put(0, "zero");
        map.put(1, "one");

        // Removing 0 ("zero") from the map.
        String removed = map.remove(0);

        // Checking if it is removed propertly.
        assertEquals("zero", removed);
        assertFalse(map.containsKey(0));
        assertEquals(1, map.getSize());

        // Removing non-existing number will throw NoSuchElementException.
        assertThrows(NoSuchElementException.class, () -> {
            map.remove(99);
        });
    }

    /**
     * This resizeTest checks if it resizes when the load factor becomes greater than or equal to 75%.
     * 
     * @return true if the tests pass, else false
     */
    @Test
    public void resizeTest() {
        // map with capacity of 8.
        HashTableMap<Integer, String> map = new HashTableMap<>(8);
        // Put 0 ("zero"), 1 ("one"), 2 ("two"), 3 ("three"), 4 ("four") in the map.
        // Total 5 items 
        map.put(0, "zero");
        map.put(1, "one");
        map.put(2, "two");
        map.put(3, "three");
        map.put(4, "four");

        // Checking if the capacity is still 8.
        assertEquals(8, map.getCapacity());
        // Checking if the capacity changes to 16 and size is 6 after adding an item.
        map.put(5, "five");
        assertEquals(16, map.getCapacity());
        assertEquals(6, map.getSize());
    }

    /**
     * This exceptionTest checks if the exceptions are thrown propertly.
     * 
     * @return true if the tests pass, else false
     */
    @Test
    public void exceptionTest() {
        // map with capacity of 4.
        HashTableMap<Integer, String> map = new HashTableMap<>(4);
        // Put 0 ("zero") in the map.
        map.put(0, "zero");

        // Putting the same key in the map will throw IllegalArgumentException.
        assertThrows(IllegalArgumentException.class, () -> {
            map.put(0, "zero");
        });

        // Putting a null key in the map will throw NullPointerException.
        assertThrows(NullPointerException.class, () -> {
            map.put(null, "null");
        });

        // Checking a null key in the map will throw NullPointerException.
        assertThrows(NullPointerException.class, () -> {
            map.containsKey(null);
        });

        // Getting a null key in the map will throw NullPointerException.
        assertThrows(NullPointerException.class, () -> {
            map.get(null);
        });

        // Removing a null key in the map will throw NullPointerException.
        assertThrows(NullPointerException.class, () -> {
            map.remove(null);
        });
    }

    /**
     * This rehashTest checks if the keys are rehashed correctly.
     * Also if getKeys() and clear() works correctly.
     * 
     * @return true if the tests pass, else false
     */
    @Test
    public void rehashTest() {
        // map with capacity of 4
        HashTableMap<Integer, String> map = new HashTableMap<>(4);
        // Put 0 ("zero"), 1 ("one") in the map.
        map.put(0, "zero");
        map.put(1, "one");
        // After adding this item, it triggers the load factor and changes the capacity to 8.
        map.put(2, "two");
        // Checking if the capacity is 8.
        assertEquals(8, map.getCapacity());
        // Checking the values after rehashing.
        assertEquals("zero", map.get(0));
        assertEquals("one", map.get(1));
        assertEquals("two", map.get(2));

        // Checking the getKeys() method.
        List<Integer> keys = map.getKeys();
        assertEquals(3, keys.size());
        assertTrue(keys.contains(0));
        assertTrue(keys.contains(1));
        assertTrue(keys.contains(2));

        // Checking the clear() method.
        map.clear();
        assertEquals(0, map.getSize());
        assertEquals(8, map.getCapacity());
        assertEquals(0, map.getKeys().size());
    }

}
