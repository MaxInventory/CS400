import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.application.Platform;
import java.util.Random;

public class ButtonGame extends Application {

    private int score = 0;

    @Override
    public void start(final Stage stage) {
	Random random = new Random();

	BorderPane root = new BorderPane();

	Label scoreLabel = new Label("Score: 0");
	root.setTop(scoreLabel);

	Button exit = new Button("Exit");
	exit.setOnAction(event -> Platform.exit());
	root.setBottom(exit);

	Pane center = new Pane();
	root.setCenter(center);
	Button[] buttons = new Button[9];
	Button target = new Button("Click me!");
	buttons[0] = target;
	for (int i = 1; i < buttons.length; i++) {
	   buttons[i] = new Button("Click me?");
	}
	for (Button button : buttons) {
	   button.setOnAction( event -> {
	      if (button == target) {
	   	score++;
	      } else {
	   	score--;
	      }
	      scoreLabel.setText("Score: " + score);
	      scrambleButtons(random, buttons);
	      exit.requestFocus();
	   });
	   center.getChildren().add(button);
	}

	scrambleButtons(random, buttons);

        Scene scene = new Scene(root, 600, 500);
        stage.setTitle("ButtonGame");
        stage.setScene(scene);
        stage.show();
	exit.requestFocus();
    }

    private void scrambleButtons(Random random, Button[] buttons) {
	for (Button button : buttons) {
	   button.setLayoutX(random.nextInt(501));
	   button.setLayoutY(random.nextInt(401));
	}
    }

    public static void main(String[] args) {
        Application.launch(args);
    }
    
}
