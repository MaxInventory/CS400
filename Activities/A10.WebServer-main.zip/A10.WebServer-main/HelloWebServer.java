import java.io.IOException;
import java.net.InetSocketAddress;
import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpContext;
import java.io.OutputStream;
import java.time.LocalDate;

public class HelloWebServer {
    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(8000),0);
        HttpContext context = server.createContext("/");
        context.setHandler(exchange -> {

		System.out.println("Server Received HTTP Request");

		String query = exchange.getRequestURI().getQuery();
		System.out.println(query);

		String course_value = "";
		String instructor_value = "";

		String[] firstSplit = query.split("&");
		for (String param : firstSplit) {
			String[] secondSplit = param.split("=");

			if (secondSplit[0].equals("course")) {
				course_value = secondSplit[1];
			}

			if (secondSplit[0].equals("instructor")) {
				instructor_value = secondSplit[1];
			}
		}

		System.out.println("course_value = " + course_value);
		System.out.println("instructor_value = " + instructor_value);

		String message = "Hello " + instructor_value + "! <br/> I hope you are having a great " + LocalDate.now();

		exchange.getResponseHeaders().add("Content-type","text/html");
		exchange.sendResponseHeaders(200, message.getBytes().length);

		OutputStream os = exchange.getResponseBody();
		os.write(message.getBytes());
		os.close();
	    });

        server.start();
	System.out.println("Hello Web Server Running...");
    }
}

