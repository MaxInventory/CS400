    /**
     * Main class for CS400 A04.FirstGit Activity Spring - 2026
     * @author: Jihun Chung, chung92
     **/
public class Main {
    public static void main(String[] args) {
	System.out.println("How do robots eat pizza?");
	System.out.println("One byte at a time.");
    }
}
